# 📋 SPESIFIKASI REVERSE ENGINEERING (REA FASE 1): TRADE IN PLUS & TRADE IN ONLINE

> **Dokumen Investigasi REA (Reverse Engineer Anything)**  
> **Target:** Trade In Plus (`com.plusphone.android`) & Trade In Online Eraspace (`com.plusphoneonline.erafone`)  
> **Lingkungan Analisis:** macOS Darwin arm64, JADX MCP 0.7.1, Apktool 2.12.1, REA CLI 6.7.0  
> **Tanggal Analisis:** 9 November 2026  
> **Tujuan:** Ekstraksi arsitektur, API endpoint, alur diagnostik hardware, modul inspeksi fisik mandiri, dan integrasi fitur ke katalog & sistem trade-in Dillah Ponsel & Komputer Tanjung Tabalong.

---

## 1. Identitas Target Aplikasi

| Properti | Target 1: Trade In Plus | Target 2: Trade In Online (Eraspace) |
| :--- | :--- | :--- |
| **Package Name** | `com.plusphone.android` | `com.plusphoneonline.erafone` |
| **App Name** | Trade In Plus | Trade In Online Eraspace |
| **Versi Aplikasi** | `3.2.89` (versionCode: `164`) | `1.4.1` (versionCode: `29`) |
| **SDK Minimal** | Android 5.0 Lollipop (`minSdkVersion: 21`) | Android 4.4 KitKat (`minSdkVersion: 19`) |
| **Target SDK** | Android 16 (`targetSdkVersion: 36`) | Android 15 (`targetSdkVersion: 35`) |
| **Arsitektur Kompilasi**| Split APK (arm64-v8a, density xxhdpi) | Split APK (arm64-v8a, density xxhdpi) |
| **Base URL Utama** | `https://admin.tradeinplus.id/` | `https://admin.tradeinonline.id/` |
| **Vendor Ekosistem** | Laku6 / PT Alisan Catur Adhirajasa | Erajaya Swasembada (Erafone / Eraspace) |

---

## 2. Arsitektur & Tech Stack

Kedua aplikasi dibangun di atas modul pustaka inti bersama: **`com.plusphone.core`** (versi SDK `1.0.1`).

- **Networking:** Retrofit 2 + OkHttp 3 + RxJava 3 (Trade In Plus) & Callbacks (Trade In Online).
- **Serialization:** Google Gson (`@SerializedName`, `@Expose`).
- **Barcode & QR Scanner:** ZXing Android Embedded (`com.journeyapps.barcodescanner`, `QRCodeWriter`, `CODE_128`).
- **Image Processing & Cropping:** Glide 4, Picasso, Soundcloud CropImage (`com.soundcloud.android.crop`).
- **Push Notification & Tracking:** Firebase Cloud Messaging (FCM), Google Play Services, Firebase Analytics & Crashlytics.
- **Dependency Injection / UI Binding:** ButterKnife (`@BindView`, `@OnClick`), Android ViewBinding / DataBinding.
- **Sensor Integration:** Android `SensorManager` (TYPE_ACCELEROMETER, TYPE_GYROSCOPE, TYPE_PROXIMITY), `Camera2` API, `AudioRecord`, `AudioManager`.

---

## 3. API Endpoints & Request/Response Signatures

### A. Trade In Plus (`https://admin.tradeinplus.id/`)

#### 1. Estimasi Harga Awal Unit
- **Endpoint:** `GET /api/harga_awal`
- **Parameter Query:**
  - `merk`: Brand produsen (contoh: `Samsung`, `Xiaomi`, `Apple`)
  - `tipe`: Model kode hardware (contoh: `SM-S928B`, `24129PN74C`)
  - `storage`: Kapasitas penyimpanan biner dalam GB (contoh: `128`, `256`, `512`, `1024`)
  - `core_sdk_version`: `1.0.1`
  - `resources_sdk_version`: `1.0.1`
  - `app_version`: `164`
- **Struktur Respons JSON:**
  ```json
  {
    "err_code": "00",
    "err_msg": "Success",
    "data_phone": {
      "harga_awal": "12500000",
      "harga_grade_a": "12500000",
      "harga_grade_b": "10800000",
      "harga_grade_c": "8500000",
      "merk": "Samsung",
      "tipe": "Galaxy S24 Ultra",
      "storage": "256"
    }
  }
  ```

#### 2. Konfigurasi Sistem & Panduan Foto Layar
- **Endpoint:** `GET /api/config` & `GET /api/config/getModelKnox`
- **Fungsi:** Mengambil ambang batas transaksi, nomor WhatsApp CS pusat (`6281296123388`), status Deal System Nego, dan aturan pengambilan foto bukti layar putih.
- **Respons JSON:**
  ```json
  {
    "success": true,
    "message": "OK",
    "data": {
      "max_nego": 2,
      "max_sub_transaction": 5,
      "nego_time_seconds": 2,
      "no_wa": "6281296123388",
      "text_logout_account_warn": "Pastikan akun (iCloud, Samsung Akun, Google, dll) dapat dihapus dan phone lock dinonaktifkan!",
      "take_photo_guides": [
        "Tampilan full layar putih dengan tulisan kode unik harus terlihat jelas",
        "Seluruh bagian smartphone harus terlihat utuh",
        "Hindari bayangan atau pantulan cahaya"
      ],
      "url_kemenperin": "https://imei.kemenperin.go.id"
    }
  }
  ```

#### 3. Submit Hasil Diagnostik Hardware
- **Endpoint:** `POST /smartphone/cek_smartphone` (Multipart / Form-Data)
- **Payload Utama:**
  - `id_pameran`: ID gerai toko/event pameran.
  - `imei`: Nomor identitas IMEI 1 & 2.
  - `serial`: Serial number perangkat.
  - `root`: Status deteksi root (binary su, Magisk, busybox).
  - `knox`: Status bit Knox warranty (`0x0` atau `0x1`).
  - `battery`: Level, suhu (°C), status pengisian daya (`isPlugged`).
  - `hardware_results`: Map status Boolean lulus/gagal dari 25 titik uji.

---

### B. Trade In Online Eraspace (`https://admin.tradeinonline.id/`)

#### 1. Estimasi Nilai Tukar Tambah Online
- **Endpoint:** `POST /online/get_price`
- **Content-Type:** `application/x-www-form-urlencoded`
- **Parameter:**
  - `merk`: String merek (`Samsung`, `Apple`, `OPPO`, dll.)
  - `tipe`: String model (`Build.MODEL`)
  - `storage`: Ukuran memori (`64`, `128`, `256`)
  - `online`: `eraspace`
  - `kode_promo`: (Opsional) Kupon promo penambahan subsidi voucher.

#### 2. Status Polling Hasil Verifikasi Unit
- **Endpoint:** `POST /eraspace/get_status`
- **Parameter:**
  - `kode_unik`: Token sesi verifikasi (dihasilkan saat mulai cek).
- **Logika Percabangan Klien:**
  - Jika `grade == "Reject"` atau `harga == "0"`: dialihkan ke `RejectActivity`.
  - Jika belum selesai: menunggu polling countdown timer.
  - Jika `grade` terbit (`A`, `B`, atau `C`): menyimpan `pref_harga_final` dan membuka `HargaFinalActivity` dengan rincian voucher tukar tambah Eraspace.

---

## 4. Alur & Modul Pengujian Diagnostik (Core Test Matrix)

Dalam modul `com.plusphone.core.tools.CheckOrderData`, terdapat 25 pengujian terpadu yang dieksekusi secara berurutan:

1. **`GPS_SENSORS`:** Memvalidasi akurasi koordinat GPS dan mendeteksi Mock Location.
2. **`VIBRATE`:** Menggetarkan motor haptic dan meminta pengguna menginput frekuensi getaran yang dirasakan (interaktif angka acak).
3. **`CHARGING`:** Memvalidasi port USB/Type-C dengan mewajibkan colok kabel cas lalu cabut (`connect_to_charger` & `unplug_charger`).
4. **`MICROPHONE`:** Merekam input audio pengguna dengan visualisasi VU-meter sampai indikator berwarna hijau.
5. **`WIFI`:** Pengecekan modul radio Wi-Fi terhubung internet.
6. **`NFC`:** Memastikan chip NFC aktif dan membaca tag.
7. **`FLASHLIGHT`:** Mengedipkan LED flash kamera beberapa kali dan meminta verifikasi visual angka kedipan.
8. **`GYROACCEL`:** Pengecekan sensor akselerometer & gyroscope dengan meminta pengguna mengayunkan HP menyerupai angka 8 (*figure-8 motion*).
9. **`PROXIMITY`:** Mendeteksi gestur tangan mendekati sensor depan (*wave to front camera*).
10. **`SPEAKER`:** Memutar frekuensi nada dan meminta input berapa kali suara berbunyi.
11. **`BLUETOOTH`:** Mengaktifkan radio Bluetooth dan mendeteksi perangkat sekitar.
12. **`BAT`:** Membaca kapasitas mAh, siklus cas (*charging cycle*), tegangan mV, dan status *health*.
13. **`POWER`:** Uji tombol fisik Power / ON-OFF.
14. **`BACK`:** Uji tombol navigasi Back fisik / gesture.
15. **`VOL`:** Uji tombol fisik Volume Atas & Volume Bawah.
16. **`BIOMETRIC`:** Uji sensor sidik jari (*fingerprint*) atau Face Unlock.
17. **`TOUCH`:** Uji digitizer layar sentuh (*touch grid boxes* yang harus diarsir penuh tanpa sisa kotak biru).
18. **`CAMERA`:** Uji jepretan kamera utama belakang, kamera telephoto, dan kamera depan selfie.
19. **`SIMCARD`:** Memastikan kartu SIM aktif dan membaca sinyal jaringan seluler.
20. **`CPU`:** Memeriksa arsitektur chipset, core count, dan frekuensi clock prosesor.
21. **`HDD`:** Memvalidasi integritas partisi internal storage dan kecepatan read/write.
22. **`ROOT`:** Uji keamanan sistem: deteksi binary su, test-keys, unlocked bootloader, dan Magisk mount.
23. **`SPEN`:** Khusus Samsung Galaxy Note & Ultra: koneksi Bluetooth S-Pen, klik tombol samping, dan hover motion di atas layar.
24. **`FOLD_SEC_LCD`:** Khusus lini lipat (Galaxy Z Fold/Flip): uji layar luar (*cover screen*).
25. **`FOLD_FIRST_LCD`:** Uji layar lipat utama bagian dalam (*inner main foldable screen*).

---

## 5. Alur Inspeksi Fisik Mandiri (Self Physical Assessment)

Pada `Trade In Online`, diterapkan sistem 4 tahap verifikasi visual mandiri:

```
[Tahap 1: GORESAN] ──> [Tahap 2: PENYOK] ──> [Tahap 3: KERUSAKAN BODI] ──> [Tahap 4: ENGSEL/LIPATAN] ──> [SUMMARY REKAP]
   Layar / Bezel          Sudut Bodi              Pecah / Retak                Khusus Z Fold/Flip          YA (Cacat) / TIDAK
```

- **Tahap 1 (`CheckFisik1Activity`): GORESAN**
  - Pertanyaan: Apakah terdapat goresan pada bodi casing atau permukaan kaca layar?
  - YA = Ada minus (Grade turun) | TIDAK = Bodi mulus bebas baret.
- **Tahap 2 (`CheckFisik2Activity`): PENYOK**
  - Pertanyaan: Apakah terdapat bekas jatuh, penyok (*dent*), atau sompal pada sudut-sudut bezel?
  - YA = Ada dent | TIDAK = Sudut utuh presisi.
- **Tahap 3 (`CheckFisik3Activity`): KERUSAKAN BODI**
  - Pertanyaan: Apakah ada retak kaca, pecahan layar, atau bodi melengkung/bengkok?
  - YA = Minus berat (potensi Reject / Grade C) | TIDAK = Normal utuh.
- **Tahap 4 (`CheckFisik4Activity`): ENGSEL & LIPATAN (Fold / Flip)**
  - Bersifat kondisional: otomatis aktif jika perangkat terdeteksi mengandung kata `"fold"` atau `"flip"` pada nama model.
  - Memeriksa kelancaran engsel dibuka 180°, tidak ada bunyi gesekan, dan *crease* (lipatan tengah) tidak mengalami garis hitam (*dead line*).

---

## 6. Output & Struk Voucher Trade-In (`KodeTradeInFinalActivity`)

Pada tahap akhir transaksi tukar tambah:
1. **Barcode CODE_128:**
   Dihasilkan menggunakan pustaka `MultiFormatWriter` ZXing untuk dibaca langsung oleh barcode scanner kasir toko fisik:
   ```java
   bitmap = encodeAsBitmap(data_summarry.getKode_tradein(), BarcodeFormat.CODE_128, width, height);
   ```
2. **QR Code Multi-Transaksi:**
   QR code kedua yang memuat payload `pref_next_trans_qr` agar pelanggan yang menukarkan lebih dari 1 HP dapat langsung memindai dari ponsel kasir tanpa mengulang data input.
3. **Struktur Ringkasan Nilai Tukar Tambah:**
   - Model & Spesifikasi Unit
   - Grade Kelayakan Fisik & Hardware (`Grade A`, `Grade B`, `Grade C`)
   - Estimasi Nilai Tukar Tambah (Rp)
   - Batas Waktu Klaim Kupon / Voucher Toko

---

## 7. Rencana Integrasi & Evolusi ke Dillah Ponsel Katalog (`dillah-katalog-android`)

Berdasarkan hasil REA, fitur unggulan yang sangat relevan diadopsi untuk meningkatkan konversi dan akurasi trade-in toko Dillah Ponsel di Tabalong adalah:

1. **Wizard 4-Langkah Inspeksi Fisik Mandiri pada Tab `Tukar`:**
   - Mengadopsi dialog visual bertahap: Goresan, Penyok/Dent, Retak/Pecah, dan Engsel (untuk seri Fold/Flip).
   - Menghasilkan auto-deduction nilai taksiran secara transparan sebelum pelanggan datang ke toko Mabuun.
2. **Peningkatan Pengujian Hardware di Tab `Diagnostik`:**
   - Menambahkan pengujian sensor Proximity (uji lambaian tangan ke kamera depan).
   - Menambahkan pengujian audio interaktif (uji frekuensi nada speaker).
3. **Cetak Barcode CODE_128 & Struk Kasir RawBT:**
   - Menambahkan kode voucher trade-in 1D Barcode (CODE_128) dan QR Code langsung pada struk cetak thermal Bluetooth untuk kasir Dillah Ponsel.
4. **Validasi Status Leasing & Garansi Resmi:**
   - Menampilkan peringatan edukasi seperti pada Trade In Plus: pembersihan akun Samsung/Google/iCloud dan cek IMEI Kemenperin / Bea Cukai.

---
*Laporan dibuat secara otomatis melalui REA (Reverse Engineer Anything).*
