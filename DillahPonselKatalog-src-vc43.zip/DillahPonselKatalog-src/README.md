# Dillah Ponsel Katalog — Source Code

APK katalog & alat kerja toko Dillah Ponsel & Komputer (Mabuun, Murung Pudak, Tabalong).
Vanilla web app di dalam WebView, di-build jadi APK dengan AAPT2 + D8 + uber-apk-signer.

- package: `com.dillahponsel.katalog`
- versionCode: 43 / versionName: 1.6.9
- minSdk 26, targetSdk 34
- commit: 1df244f — "feat(evolution): buku taksiran kasir dengan grafik tren harian (uPlot, offline)"

## Struktur

```
AndroidManifest.xml              permission, provider, activity, queries
src/com/dillahponsel/katalog/
  MainActivity.java              WebView host + jembatan Java (1292 baris)
  GenericFileProvider.java       FileProvider untuk bagikan/instal file
res/                             ikon launcher + strings
assets/
  index.html                     seluruh UI + logika toko (8301 baris)
  data/produk.js                 katalog HP baru & seken
  data/seken.js                  stok unit seken
  data/news.js                   cache feed berita
  data/cctv.js                   daftar CCTV toko
  data/poi.js                    titik lokasi/POI sekitar
  lib/comparator.js              komparasi spek berdampingan
  lib/wishlist.js                daftar incaran + planner budget
  lib/signature.js               pad tanda tangan persetujuan tukar tambah
  lib/ledger.js                  buku taksiran kasir + grafik tren harian
  lib/fuzzysort.min.js           pencarian toleran typo
  lib/qrcode.min.js              QR code offline
  lib/signature_pad.min.js       mesin gambar tanda tangan
  lib/uplot.min.js               grafik
  lib/uplot.layout.css           layout grafik (CSS flat, bukan nesting)
  lib/hls.min.js                 pemutar stream CCTV
  lib/*.LICENSE.txt              lisensi upstream
build.sh                         build manual
verify_and_build.sh              quality gate + build + publish Telegram
selftest_*.js                    smoke test DOM lewat CDP
wshelper.js                      klien WebSocket native untuk CDP
publish_telegram_update.py       kirim APK ke channel Telegram
GoogleAppsScript_QC_DillahPonsel.js  backend Google Sheets untuk QC
EVOLUTION_GUARDRAILS.md          aturan yang tidak boleh dilanggar
```

## Enam tab inti

| Tab | Isi |
|---|---|
| `tab-baru` | katalog HP baru, harga, cicilan, tombol order WhatsApp |
| `tab-seken` | stok unit bekas + kondisi + harga |
| `tab-tukar` | kalkulator tukar tambah, margin appraisal, tanda tangan pelanggan |
| `tab-diag` | QC interaktif: IMEI Luhn, dead pixel, touch grid, kamera, baterai, Knox, MDM |
| `tab-cctv` | stream CCTV toko (HLS) |
| `tab-toko` | info toko, lokasi, kontak, update APK |

## Build

Butuh JDK, Android SDK build-tools (aapt2, d8), dan uber-apk-signer.

```bash
./verify_and_build.sh     # gate selftest -> bump versionCode -> compile -> publish
# hasil: dist/DillahPonselKatalog.apk
```

`build.sh` menjalankan kompilasi tanpa gate, untuk build cepat saat debug.

## Aturan yang dijaga

- Tidak ada CDN eksternal. Semua library ada di `assets/lib/` beserta LICENSE upstream.
- Offline-first: persistensi hanya lewat localStorage, tidak ada jalur tulis ke jaringan
  selain webhook QC dan WhatsApp.
- Enam tab inti, `WA_NUMBER`, rumus margin appraisal, dan skema `assets/data/*.js`
  tidak diubah oleh penambahan fitur.

## Catatan

- `assets/index.html` berisi seluruh logika toko dalam satu file. Itu warisan desain awal,
  bukan pilihan arsitektur; memecahnya butuh refactor bertahap karena banyak handler
  dipanggil langsung dari atribut HTML.
- APK hasil build ditandatangani debug key. Untuk distribusi lewat Play Store perlu
  keystore rilis sendiri.
- `dist/` dan `build/` sengaja tidak disertakan di arsip ini karena isinya artefak kompilasi.
