#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$DIR"

export JAVA_HOME=/opt/homebrew/opt/openjdk@17
export PATH="$JAVA_HOME/bin:$PATH"

AAPT2=/opt/homebrew/share/android-commandlinetools/build-tools/34.0.0/aapt2
D8=/opt/homebrew/share/android-commandlinetools/build-tools/34.0.0/d8
AJ=/opt/homebrew/share/android-commandlinetools/platforms/android-34/android.jar
SIGNER=/Users/arsya/.hermes/tools/mockloc/bin/uber-apk-signer.jar

echo "==> Membersihkan build folder..."
rm -rf build
mkdir -p build/gen build/classes build/dex dist

echo "==> Compile resources..."
"$AAPT2" compile --dir res -o build/res.zip

echo "==> Link APK & generate R.java..."
"$AAPT2" link build/res.zip -I "$AJ" --manifest AndroidManifest.xml -A assets --java build/gen -o build/app.unsigned.apk --auto-add-overlay

echo "==> Compile Java sources..."
javac -cp "$AJ" -d build/classes $(find src build/gen -name "*.java")

echo "==> D8 Dexing..."
"$D8" --output build/dex --lib "$AJ" $(find build/classes -name "*.class")

echo "==> Inject classes.dex..."
(cd build/dex && zip -u ../app.unsigned.apk classes.dex >/dev/null)

echo "==> Signing APK..."
java -jar "$SIGNER" --apks build/app.unsigned.apk --out dist >/dev/null

cp dist/*-aligned-debugSigned.apk dist/DillahPonselKatalog.apk
cp dist/DillahPonselKatalog.apk /Users/arsya/Desktop/DillahPonselKatalog.apk

echo "==> SELESAI!"
ls -lh dist/DillahPonselKatalog.apk
