#!/usr/bin/env python3
"""
Publish Dillah Ponsel APK Update to Telegram
Mengirim file APK terkompilasi ke Telegram (Dillah Kaixa) dan mem-pin pesannya
sehingga aplikasi klien Android dapat mendeteksi dan mengunduh pembaruan otomatis.
"""

import os
import re
import sys
import json
import urllib.request
import urllib.parse

DIR = os.path.dirname(os.path.abspath(__file__))
MANIFEST_PATH = os.path.join(DIR, "AndroidManifest.xml")
APK_PATH = os.path.join(DIR, "dist", "DillahPonselKatalog.apk")
ENV_PATH = os.path.expanduser("~/.hermes/.env")

def get_telegram_creds():
    token = None
    chat_id = "491782072"
    if os.path.exists(ENV_PATH):
        with open(ENV_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("TELEGRAM_BOT_TOKEN="):
                    token = line.split("=", 1)[1].strip().strip('"').strip("'")
                elif line.startswith("TELEGRAM_ALLOWED_USERS="):
                    val = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if val:
                        chat_id = val.split(",")[0].strip()
    return token, chat_id

def get_manifest_version():
    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        text = f.read()
    vc = re.search(r'android:versionCode="(\d+)"', text).group(1)
    vn = re.search(r'android:versionName="([^"]+)"', text).group(1)
    return int(vc), vn

def main():
    if not os.path.exists(APK_PATH):
        print(f"Error: APK not found at {APK_PATH}")
        sys.exit(1)

    token, chat_id = get_telegram_creds()
    if not token:
        print("Error: TELEGRAM_BOT_TOKEN not found in ~/.hermes/.env")
        sys.exit(1)

    vc, vn = get_manifest_version()
    file_size_kb = os.path.getsize(APK_PATH) // 1024

    caption = (
        f"📦 <b>Dillah Ponsel Katalog — Update APK Baru</b>\n\n"
        f"• <b>Versi:</b> v{vn} (Build {vc})\n"
        f"• <b>Ukuran:</b> {file_size_kb} KB\n"
        f"• <b>Status:</b> Siap instal & bagikan ke pelanggan\n\n"
        f"Aplikasi klien akan otomatis mendeteksi rilis ini dan mengunduh pembaruan.\n\n"
        f"#DILLAH_UPDATE versionCode={vc} versionName={vn}"
    )

    print(f"==> Mengunggah APK v{vn} (Build {vc}, {file_size_kb} KB) ke Telegram chat {chat_id}...")

    boundary = "----WebKitFormBoundaryDillahKatalogUpdate"
    body = []

    def add_field(name, val):
        body.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{val}\r\n".encode("utf-8"))

    add_field("chat_id", chat_id)
    add_field("caption", caption)
    add_field("parse_mode", "HTML")

    with open(APK_PATH, "rb") as f:
        apk_data = f.read()

    filename = f"DillahPonselKatalog_v{vn}_b{vc}.apk"
    body.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"document\"; filename=\"{filename}\"\r\nContent-Type: application/vnd.android.package-archive\r\n\r\n".encode("utf-8"))
    body.append(apk_data)
    body.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))

    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendDocument",
        data=b"".join(body),
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "User-Agent": "DillahPonselBuilder/1.0"
        },
        method="POST"
    )

    import time
    msg_id = None
    file_id = None
    for attempt in range(1, 4):
        try:
            print(f"   [Upload ke Telegram: Percobaan {attempt}/3]...")
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                if data.get("ok"):
                    msg_id = data["result"]["message_id"]
                    file_id = data["result"]["document"]["file_id"]
                    print(f"✓ Berhasil dikirim! Message ID: {msg_id}, File ID: {file_id}")
                    break
                else:
                    print(f"Peringatan respons Telegram: {data}")
        except Exception as e:
            print(f"   Upload gagal pada percobaan {attempt}: {e}")
            if attempt < 3:
                time.sleep(2)
            else:
                print("Peringatan: Gagal unggah ke Telegram setelah 3 percobaan. Melanjutkan build lokal.")
                return

    # Pin pesan di chat
    try:
        pin_url = f"https://api.telegram.org/bot{token}/pinChatMessage?chat_id={chat_id}&message_id={msg_id}&disable_notification=true"
        with urllib.request.urlopen(pin_url, timeout=15) as resp:
            pin_data = json.loads(resp.read().decode("utf-8"))
            if pin_data.get("ok"):
                print("✓ Pesan update berhasil di-pin di chat Telegram!")
            else:
                print("Peringatan saat pin pesan:", pin_data)
    except Exception as e:
        print("Warning saat pin pesan:", e)

    print(f"==> [Telegram Auto-Update] Rilis v{vn} (Build {vc}) siap untuk seluruh perangkat!")

if __name__ == "__main__":
    main()
