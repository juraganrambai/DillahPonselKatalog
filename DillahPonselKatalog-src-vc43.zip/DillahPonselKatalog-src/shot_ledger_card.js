#!/usr/bin/env node
/**
 * Tangkap gambar khusus kartu "Buku Taksiran Kasir" (clip presisi, 2x DPR)
 * sebagai bukti visual untuk laporan Telegram.
 */
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");

const DIR = path.resolve(__dirname);
const PORT = 9720 + Math.floor(Math.random() * 200);
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const PAGE = "file://" + path.join(DIR, "assets", "index.html");
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function cdp(ws, method, params) {
  return new Promise((resolve, reject) => {
    const id = ++ws._id;
    const off = ws.onMessage((m) => {
      if (m.id === id) { off(); m.error ? reject(new Error(method + ": " + JSON.stringify(m.error))) : resolve(m.result); }
    });
    ws.send({ id, method, params: params || {} });
    setTimeout(() => { off(); reject(new Error("timeout " + method)); }, 30000);
  });
}
async function evalJS(ws, expr) {
  const res = await cdp(ws, "Runtime.evaluate", { expression: expr, awaitPromise: true, returnByValue: true });
  if (res.exceptionDetails) throw new Error("JS exception: " + JSON.stringify(res.exceptionDetails.exception || res.exceptionDetails.text));
  return res.result.value;
}

(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), "ledgershot_"));
  const chrome = spawn(CHROME, ["--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run",
    "--remote-debugging-port=" + PORT, "--user-data-dir=" + profile, "--allow-file-access-from-files",
    "--window-size=412,915", "--force-device-scale-factor=2", PAGE], { stdio: "ignore" });

  const out = {};
  let ws;
  try {
    let pageTarget = null;
    for (let i = 0; i < 60; i++) {
      try {
        const r = await fetch(`http://127.0.0.1:${PORT}/json/list`);
        const t = await r.json();
        pageTarget = t.find(x => x.type === "page" && x.url === PAGE && x.webSocketDebuggerUrl);
        if (pageTarget) break;
      } catch (e) {}
      await sleep(300);
    }
    if (!pageTarget) throw new Error("target tidak ditemukan");
    const { connectWS } = require("./wshelper.js");
    ws = await connectWS(pageTarget.webSocketDebuggerUrl);
    ws._id = 0;
    await cdp(ws, "Runtime.enable");
    await sleep(2600);

    await evalJS(ws, `(async () => {
      DillahLedger.clear();
      const now = Date.now();
      const seed = [
        ["iPhone 11 128GB", "iPhone 13 128GB", 4200000, 3610000, 0],
        ["Redmi Note 10", "Redmi Note 13", 1450000, 1180000, 1],
        ["Samsung A54 256GB", "Samsung A55 5G", 3100000, 2650000, 1],
        ["Oppo Reno 8", "Oppo Reno 11", 2750000, 2180000, 2],
        ["Vivo V29 256GB", "Vivo V30", 3600000, 3120000, 3],
        ["Realme 11 Pro", "Realme 12 Pro", 2400000, 1950000, 4],
        ["POCO X5 Pro", "POCO X6 Pro", 2050000, 1620000, 6],
        ["Infinix Note 30", "Infinix Note 40", 1350000, 980000, 9],
        ["Asus Zenfone 9", "Zenfone 10", 3900000, 3010000, 12]
      ];
      seed.forEach((s, i) => DillahLedger.upsert({
        kode: "DLH-TT-" + (2611) + "-" + (7000 + i), namaLama: s[0], namaTujuan: s[1],
        pasaran: s[2], taksiran: s[3], selisih: 2000000,
        grade: "grade_a", sinyal: "resmi", kelengkapan: "fullset",
        ts: now - s[4] * 86400000
      }));
      const navItem = document.querySelectorAll(".nav-item")[2];
      if (navItem && window.onNavClick) window.onNavClick(navItem, 2);
      window.setLedgerRange(14);
      await new Promise(r => setTimeout(r, 700));
      return true;
    })()`);
    await sleep(900);

    const box = await evalJS(ws, `(() => {
      const el = document.getElementById("ledgerCard");
      el.scrollIntoView({ block: "center" });
      const b = el.getBoundingClientRect();
      return { x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height) };
    })()`);
    await sleep(600);

    const shot = await cdp(ws, "Page.captureScreenshot", {
      format: "png",
      captureBeyondViewport: true,
      clip: { x: box.x - 6, y: box.y - 6, width: box.w + 12, height: box.h + 12, scale: 2 }
    });
    const file = path.join(DIR, "selftest_ledger_card.png");
    fs.writeFileSync(file, Buffer.from(shot.data, "base64"));
    out.card = file;
    out.bytes = fs.statSync(file).size;
    out.box = box;
  } catch (e) {
    out.fatal = e.message;
  } finally {
    try { if (ws) ws.close(); } catch (e) {}
    chrome.kill("SIGKILL");
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  }
  console.log(JSON.stringify(out, null, 2));
})();
