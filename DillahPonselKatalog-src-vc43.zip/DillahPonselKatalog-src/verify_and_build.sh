#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$DIR"

echo "==> [Quality Gate 1/3] Headless Smoke Test & JS Syntax Validator..."
node -e '
const fs = require("fs");
const html = fs.readFileSync("assets/index.html", "utf8");
const scriptMatches = html.match(/<script[\s\S]*?<\/script>/gi) || [];
let hasError = false;
scriptMatches.forEach((s, idx) => {
  const content = s.replace(/<script[^>]*>/i, "").replace(/<\/script>/i, "");
  if (!s.includes("src=")) {
    try {
      new Function(content);
    } catch (err) {
      console.error(`ERROR: Inline Script ${idx} Syntax Error:`, err.message);
      hasError = true;
    }
  }
});
if (hasError) process.exit(1);
console.log("All inline scripts passed JavaScript syntax check.");
'

CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

# Run headless check and capture JS errors
ERROR_LOG="/tmp/dillah_smoke_error.log"
DOM_OUT="/tmp/dillah_smoke_dom.html"
CHROME_PROFILE="$(mktemp -d /tmp/dillah_chrome_XXXXXX)"
timeout 120 "$CHROME" --headless --disable-gpu --no-first-run --user-data-dir="$CHROME_PROFILE" --virtual-time-budget=5000 --dump-dom "file://$DIR/assets/index.html" >"$DOM_OUT" 2>"$ERROR_LOG" || true
rm -rf "$CHROME_PROFILE"

python3 -c "
dom = open('$DOM_OUT', encoding='utf-8', errors='replace').read()
err = open('$ERROR_LOG', encoding='utf-8', errors='replace').read()
assert len(dom) > 20000, f'Headless render terlalu kecil ({len(dom)} byte) — halaman gagal dimuat'
assert 'item-price' in dom, 'Kartu produk tidak ter-render di DOM'
bad = [l for l in err.splitlines() if 'Uncaught' in l or 'SyntaxError' in l]
assert not bad, 'JS error terdeteksi: ' + bad[0]
print(f'Headless render OK: {len(dom)} byte, kartu produk ter-render, 0 JS error.')
"

# Check if file has syntax crash
python3 -c "
import urllib.parse
html = open('$DIR/assets/index.html').read()
assert 'bottom-nav' in html, 'Missing bottom-nav in DOM'
assert 'WA_NUMBER' in html, 'Missing WA_NUMBER constant'
assert 'tab-baru' in html and 'tab-seken' in html, 'Missing core catalog tabs'
print('DOM structure & core constants intact.')
"

echo "==> [Quality Gate 1b/3] Smoke test modul tanda tangan pelanggan..."
node selftest_signature.js > /tmp/dillah_sig_selftest.json 2>&1 || true
python3 -c "
import json
raw = open('/tmp/dillah_sig_selftest.json', encoding='utf-8', errors='replace').read()
# Ambil blok JSON saja (baris log lain mungkin ikut tercetak)
start = raw.find('{')
end = raw.rfind('}')
try:
    r = json.loads(raw[start:end + 1]) if start != -1 and end > start else None
except Exception:
    r = None
if not isinstance(r, dict):
    raise AssertionError('Self-test TTD tidak menghasilkan JSON valid: ' + raw[:400])

checks = {
    'lib signature_pad termuat': r.get('signaturePadLoaded') is True,
    'modul DillahSignature termuat': r.get('dillahSigLoaded') is True,
    'sheet tanda tangan terbuka': r.get('sheetVisible') is True,
    'kanvas berukuran benar': r.get('canvasSized') is True,
    'goresan terekam': r.get('padNotEmpty') is True,
    'TTD tersimpan ke localStorage': bool(r.get('savedRecord')) and r['savedRecord'].get('isPng') is True,
    'pratinjau tampil': r.get('previewVisible') is True,
    'pratinjau ter-decode & ada tinta': bool(r.get('previewDecoded')) and r['previewDecoded'].get('inkPx', 0) > 200,
    'TTD tergambar di kartu nota': bool(r.get('cardPixels')) and r['cardPixels'].get('brightPx', 0) > 1000,
    'struk thermal memuat baris TTD': isinstance(r.get('receipt'), dict) and bool(r['receipt'].get('hasTtdLine')),
    'hapus TTD membersihkan state': bool(r.get('afterRemove')) and r['afterRemove'].get('rec') is None,
    'guard TTD kosong ditolak': r.get('emptyGuard') is True,
    '0 JS error': r.get('jsErrors') == []
}
gagal = [nama for nama, ok in checks.items() if not ok]
if gagal:
    raise AssertionError('Smoke test TTD GAGAL: ' + ', '.join(gagal) + ' | raw=' + raw[:500])
print('Tanda tangan pelanggan: ' + str(len(checks)) + '/' + str(len(checks)) + ' pemeriksaan lolos.')
"

echo "==> [Quality Gate 1c/3] Smoke test buku taksiran & grafik tren..."
node selftest_ledger.js > /tmp/dillah_ledger_selftest.json 2>&1 || true
python3 -c "
import json
raw = open('/tmp/dillah_ledger_selftest.json', encoding='utf-8', errors='replace').read()
start = raw.find('{')
end = raw.rfind('}')
try:
    r = json.loads(raw[start:end + 1]) if start != -1 and end > start else None
except Exception:
    r = None
if not isinstance(r, dict):
    raise AssertionError('Self-test buku taksiran tidak menghasilkan JSON valid: ' + raw[:400])

fe = r.get('firstEntry') or {}
ch = r.get('chart') or {}
st = r.get('stats') or {}
nd = r.get('noDuplicate') or {}
nw = r.get('newDeal') or {}
se = r.get('series') or {}
cs = r.get('csv') or {}
ac = r.get('afterClear') or {}
rg = r.get('ranges') or {}

checks = {
    'lib uPlot termuat': r.get('uplotLoaded') is True,
    'modul DillahLedger termuat': r.get('ledgerLoaded') is True,
    'entri taksiran tersimpan': fe.get('count') == 1 and fe.get('storedInLs') is True,
    'entri memuat nilai pasaran & taksiran': bool(fe.get('rec')) and fe['rec'].get('pasaran', 0) > 0 and fe['rec'].get('taksiran', 0) > 0,
    'grafik tergambar (ada piksel tinta)': ch.get('inkPx', 0) > 500,
    'kotak statistik ter-render': st.get('cards') == 3,
    'daftar taksiran terakhir tampil': st.get('recentRows', 0) >= 1,
    'tidak ada entri duplikat saat nilai diubah': nd.get('count') == 1,
    'ganti tipe HP lama -> voucher baru': nw.get('voucherChanged') is True and nw.get('count') == 2,
    'deret harian 14 titik': se.get('points') == 14 and se.get('todayCount', 0) >= 1,
    'ekspor CSV berisi header + baris': cs.get('hasHeader') is True and cs.get('rows') == 2,
    'rentang 7H/14H/30H berfungsi': bool(rg) and all(rg.values()),
    'hapus semua membersihkan state': ac.get('count') == 0 and ac.get('emptyVisible') is True,
    '0 JS error': r.get('jsErrors') == []
}
gagal = [nama for nama, ok in checks.items() if not ok]
if gagal:
    raise AssertionError('Smoke test buku taksiran GAGAL: ' + ', '.join(gagal) + ' | raw=' + raw[:500])
print('Buku taksiran & grafik tren: ' + str(len(checks)) + '/' + str(len(checks)) + ' pemeriksaan lolos.')
"

echo "==> [Quality Gate 2/3] Incrementing versionCode & versionName..."
python3 -c "
import re
with open('AndroidManifest.xml', 'r') as f:
    manifest = f.read()

vc = int(re.search(r'android:versionCode=\"(\d+)\"', manifest).group(1))
new_vc = vc + 1
manifest = re.sub(r'android:versionCode=\"\d+\"', f'android:versionCode=\"{new_vc}\"', manifest)

vn_match = re.search(r'android:versionName=\"(\d+)\.(\d+)\.(\d+)\"', manifest)
if vn_match:
    major, minor, patch = (int(x) for x in vn_match.groups())
    new_vn = f'{major}.{minor}.{patch + 1}'
    manifest = re.sub(r'android:versionName=\"[\d.]+\"', f'android:versionName=\"{new_vn}\"', manifest)
    print(f'versionName updated: {vn_match.group(0).split(chr(34))[1]} -> {new_vn}')
else:
    print('versionName tidak berformat x.y.z — dilewati')

with open('AndroidManifest.xml', 'w') as f:
    f.write(manifest)
print(f'versionCode updated: {vc} -> {new_vc}')
"

echo "==> [Quality Gate 3/3] Compiling APK..."
./build.sh

echo "==> [Telegram Auto-Update] Mempublikasikan APK rilis ke Telegram Cloud..."
python3 publish_telegram_update.py

echo "==> [Quality Gate Selesai] Build sukses dan terverifikasi!"
