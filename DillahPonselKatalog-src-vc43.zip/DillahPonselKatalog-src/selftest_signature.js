#!/usr/bin/env node
/**
 * Self-test headless untuk fitur tanda tangan digital pelanggan.
 * Menjalankan assets/index.html di Chrome headless via CDP, mensimulasikan
 * goresan jari pada kanvas, menyimpan TTD, lalu memverifikasi:
 *  1. lib signature_pad termuat & SignaturePad tersedia
 *  2. simpan TTD -> localStorage terisi, pratinjau tampil, status berubah
 *  3. TTD ikut tergambar di kartu nota PNG (bukti piksel)
 *  4. struk thermal memuat baris "TTD Pelanggan:"
 *  5. hapus TTD -> localStorage bersih, status kembali "Belum ditandatangani"
 */
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");

const DIR = path.resolve(__dirname);
// Port acak bebas: hindari tabrakan dengan Chrome debug lain di mesin ini
const PORT = 9400 + Math.floor(Math.random() * 400);
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const PAGE = "file://" + path.join(DIR, "assets", "index.html");

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function cdp(ws, method, params) {
  return new Promise((resolve, reject) => {
    const id = ++ws._id;
    const off = ws.onMessage((m) => {
      if (m.id === id) {
        off();
        m.error ? reject(new Error(method + ": " + JSON.stringify(m.error))) : resolve(m.result);
      }
    });
    ws.send({ id, method, params: params || {} });
    setTimeout(() => { off(); reject(new Error("timeout " + method)); }, 30000);
  });
}

async function evalJS(ws, expr) {
  const res = await cdp(ws, "Runtime.evaluate", {
    expression: expr,
    awaitPromise: true,
    returnByValue: true
  });
  if (res.exceptionDetails) {
    throw new Error("JS exception: " + JSON.stringify(res.exceptionDetails.exception || res.exceptionDetails.text));
  }
  return res.result.value;
}

(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), "sigtest_"));
  const chrome = spawn(CHROME, [
    "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
    "--remote-debugging-port=" + PORT, "--user-data-dir=" + profile,
    "--allow-file-access-from-files", "--window-size=412,915", PAGE
  ], { stdio: "ignore" });

  const results = {};
  let ws;
  try {
    // tunggu devtools
    let targets = null;
    let pageTarget = null;
    for (let i = 0; i < 60; i++) {
      try {
        const r = await fetch(`http://127.0.0.1:${PORT}/json/list`);
        targets = await r.json();
        pageTarget = targets.find(t => t.type === "page" && t.url === PAGE && t.webSocketDebuggerUrl);
        if (pageTarget) break;
      } catch (e) {}
      await sleep(300);
    }
    if (!pageTarget) throw new Error("Target halaman tidak ditemukan di port " + PORT);
    const page = pageTarget;
    const { connectWS } = require("./wshelper.js");
    ws = await connectWS(page.webSocketDebuggerUrl);
    ws._id = 0;

    await cdp(ws, "Runtime.enable");
    await cdp(ws, "Page.enable");
    // Selaraskan konteks eksekusi ke dokumen final (pola sama dengan probe yang terbukti)
    await sleep(1200);
    await cdp(ws, "Page.reload", { ignoreCache: true });
    await sleep(2500);

    // Tunggu app benar-benar siap (skrip inline & lib sudah dievaluasi)
    let ready = false;
    let lastProbe = null;
    for (let i = 0; i < 60; i++) {
      const probe = await evalJS(ws, `(function(){ try { return {ok: document.readyState === "complete" &&
        typeof window.SignaturePad === "function" &&
        typeof window.DillahSignature === "object" &&
        typeof state === "object", rs: document.readyState, sp: typeof window.SignaturePad, ds: typeof window.DillahSignature, st: typeof state, title: document.title, nscripts: document.scripts.length, url: location.href, ctxGlobal: Object.keys(window).length}; } catch(e) { return {ok:false, err:String(e)}; } })()`).catch((e) => ({ ok: false, err: "evalfail:" + e.message }));
      lastProbe = probe;
      if (probe && probe.ok === true) { ready = true; break; }
      await sleep(300);
    }
    results.appReady = ready;
    results.appReadyProbe = lastProbe;
    if (!ready) throw new Error("App tidak siap setelah 18s");
    await sleep(600);

    // 1. Modul tersedia
    results.signaturePadLoaded = await evalJS(ws, "typeof window.SignaturePad === 'function'");
    results.dillahSigLoaded = await evalJS(ws, "typeof window.DillahSignature === 'object' && typeof DillahSignature.save === 'function'");

    // Buat voucher + aktifkan blok voucher (mensimulasikan kalkulator terisi)
    results.setup = await evalJS(ws, `(() => {
      state.currentTradeInVoucher = "DLH-TT-TEST-9001";
      document.getElementById("boxVoucherBarcode").style.display = "block";
      document.getElementById("ttdStatusText").innerText = "Belum ditandatangani";
      window.refreshSignaturePreview();
      return true;
    })()`);

    // 2. Buka sheet tanda tangan
    await evalJS(ws, "window.openSignatureSheet(); true");
    await sleep(500);
    results.sheetVisible = await evalJS(ws, "document.getElementById('modalSignature').style.display === 'flex'");
    results.canvasSized = await evalJS(ws, "(() => { const c = document.getElementById('sigPadCanvas'); return c.width > 100 && c.height > 100; })()");

    // 3. Simulasi goresan jari (pointer events di Chrome headless = mouse)
    const box = await evalJS(ws, `(() => {
      const c = document.getElementById('sigPadCanvas');
      const r = c.getBoundingClientRect();
      return { x: r.left, y: r.top, w: r.width, h: r.height };
    })()`);

    const stroke = [
      [box.x + box.w * 0.15, box.y + box.h * 0.62],
      [box.x + box.w * 0.28, box.y + box.h * 0.32],
      [box.x + box.w * 0.40, box.y + box.h * 0.66],
      [box.x + box.w * 0.52, box.y + box.h * 0.30],
      [box.x + box.w * 0.64, box.y + box.h * 0.58],
      [box.x + box.w * 0.80, box.y + box.h * 0.42]
    ];

    await cdp(ws, "Input.dispatchMouseEvent", { type: "mousePressed", x: stroke[0][0], y: stroke[0][1], button: "left", clickCount: 1 });
    for (let i = 1; i < stroke.length; i++) {
      // interpolasi supaya kurva terbentuk mulus
      const [px, py] = stroke[i - 1];
      const [cx, cy] = stroke[i];
      for (let s = 1; s <= 6; s++) {
        await cdp(ws, "Input.dispatchMouseEvent", {
          type: "mouseMoved",
          x: px + (cx - px) * (s / 6),
          y: py + (cy - py) * (s / 6),
          button: "left", buttons: 1
        });
        await sleep(12);
      }
    }
    await cdp(ws, "Input.dispatchMouseEvent", { type: "mouseReleased", x: stroke[stroke.length - 1][0], y: stroke[stroke.length - 1][1], button: "left", clickCount: 1 });
    await sleep(400);

    results.padNotEmpty = await evalJS(ws, "typeof sigPad !== 'undefined' && sigPad && !sigPad.isEmpty()");
    results.placeholderHidden = await evalJS(ws, "document.getElementById('sigPlaceholder').style.display === 'none'");

    // 4. Simpan dengan nama
    await evalJS(ws, `(() => { document.getElementById('sigNamaInput').value = "Budi Santoso"; return true; })()`);
    await evalJS(ws, "window.saveSignaturePad(); true");
    await sleep(600);

    results.savedRecord = await evalJS(ws, `(() => {
      const rec = DillahSignature.get("DLH-TT-TEST-9001");
      return rec ? { nama: rec.nama, bytes: rec.dataUrl.length, isPng: rec.dataUrl.startsWith("data:image/png") } : null;
    })()`);

    results.previewVisible = await evalJS(ws, "document.getElementById('ttdPreviewWrap').style.display === 'block'");
    results.previewImgHasSrc = await evalJS(ws, "!!document.getElementById('ttdPreviewImg').getAttribute('src')");
    results.statusText = await evalJS(ws, "document.getElementById('ttdStatusText').innerText");
    results.sheetClosed = await evalJS(ws, "document.getElementById('modalSignature').style.display === 'none'");
    results.btnLabel = await evalJS(ws, "document.getElementById('btnTtdSign').innerText");

    // 4b. Pratinjau benar-benar ter-decode & mengandung goresan (bukan gambar kosong)
    results.previewDecoded = await evalJS(ws, `(async () => {
      const img = document.getElementById("ttdPreviewImg");
      if (!img || !img.getAttribute("src")) return { error: "src kosong" };
      if (!img.complete) await new Promise(r => { img.onload = r; img.onerror = r; });
      await new Promise(r => setTimeout(r, 200));
      if (!img.naturalWidth) return { error: "gambar gagal decode" };
      const cv = document.createElement("canvas");
      cv.width = img.naturalWidth; cv.height = img.naturalHeight;
      const cx = cv.getContext("2d");
      cx.drawImage(img, 0, 0);
      const d = cx.getImageData(0, 0, cv.width, cv.height).data;
      let ink = 0, total = cv.width * cv.height;
      for (let i = 0; i < d.length; i += 4) {
        if (d[i+3] > 10 && (0.299*d[i] + 0.587*d[i+1] + 0.114*d[i+2]) < 110) ink++;
      }
      return { w: cv.width, h: cv.height, inkPx: ink, inkPct: +(ink / total * 100).toFixed(2) };
    })()`);

    // 5. Kartu nota PNG harus memuat TTD -> ukur piksel gelap di area tanda tangan
    results.cardPixels = await evalJS(ws, `(async () => {
      // Tangkap canvas hasil generateTradeInReceiptCard dengan membajak toDataURL
      const origCreate = document.createElement.bind(document);
      let captured = null;
      const orig = HTMLCanvasElement.prototype.toDataURL;
      HTMLCanvasElement.prototype.toDataURL = function(t, q) {
        captured = this;
        return orig.call(this, t, q);
      };
      try {
        // netralkan download supaya headless tidak mengunduh
        const realClick = HTMLAnchorElement.prototype.click;
        HTMLAnchorElement.prototype.click = function() {};
        window.generateTradeInReceiptCard();
        await new Promise(r => setTimeout(r, 1200));
        HTMLAnchorElement.prototype.click = realClick;
      } finally {
        HTMLCanvasElement.prototype.toDataURL = orig;
      }
      if (!captured) return { error: "canvas tidak tertangkap" };
      const c = captured;
      const ctx = c.getContext("2d");
      // Area kotak TTD: x 40..600, y 610..730
      const d = ctx.getImageData(40, 640, 520, 70).data;
      let dark = 0, bright = 0;
      for (let i = 0; i < d.length; i += 4) {
        const lum = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2];
        if (lum > 120) bright++;
        else dark++;
      }
      window.__cardPng = c.toDataURL("image/png");
      return { w: c.width, h: c.height, brightPx: bright, darkPx: dark, totalPx: dark + bright };
    })()`);

    // Simpan PNG kartu nota untuk verifikasi visual
    try {
      const png = await evalJS(ws, "window.__cardPng || null");
      if (png && png.startsWith("data:image/png")) {
        const out = path.join(DIR, "selftest_nota_ttd.png");
        fs.writeFileSync(out, Buffer.from(png.split(",")[1], "base64"));
        results.cardPngSaved = out;
        results.cardPngBytes = fs.statSync(out).size;
      }
    } catch (e) { results.cardPngSaved = "err:" + e.message; }

    // 6. Struk thermal memuat baris TTD (stub AndroidDiag.printRawBt = jalur utama)
    results.receipt = await evalJS(ws, `(() => {
      let captured = null;
      window.AndroidDiag = window.AndroidDiag || {};
      const orig = window.AndroidDiag.printRawBt;
      window.AndroidDiag.printRawBt = function(text) { captured = text; return true; };
      try { window.printTradeInReceipt(); } catch(e) { return "ERR:" + e.message; }
      window.AndroidDiag.printRawBt = orig;
      if (!captured) return "no-capture";
      return {
        hasTtdLine: captured.split("\\n").filter(l => l.includes("TTD Pelanggan")),
        totalLines: captured.split("\\n").length,
        voucherLine: captured.split("\\n").filter(l => l.includes("No Voucher"))
      };
    })()`);

    // 7. Hapus TTD -> bersih
    results.afterRemove = await evalJS(ws, `(() => {
      window.removeSignature();
      return {
        rec: DillahSignature.get("DLH-TT-TEST-9001"),
        status: document.getElementById("ttdStatusText").innerText,
        previewWrap: document.getElementById("ttdPreviewWrap").style.display
      };
    })()`);

    // 8. Guard: simpan tanpa goresan ditolak
    results.emptyGuard = await evalJS(ws, `(() => {
      window.openSignatureSheet();
      window.clearSignaturePad();
      window.saveSignaturePad();
      return DillahSignature.get("DLH-TT-TEST-9001") === null;
    })()`);
    await evalJS(ws, "window.closeSignatureSheet(); true");

    // 9. Error console selama semua langkah
    results.jsErrors = await evalJS(ws, "window.__jsErrors ? window.__jsErrors : []");

  } catch (e) {
    results.fatal = e.message;
  } finally {
    try { if (ws) ws.close(); } catch (e) {}
    chrome.kill("SIGKILL");
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  }

  console.log(JSON.stringify(results, null, 2));
})();
