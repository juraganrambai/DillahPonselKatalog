/**
 * Wrapper WebSocket minimal di atas WebSocket native Node (tanpa dependensi npm).
 * API: send(obj), onMessage(cb), close()
 */
function connectWS(url) {
  return new Promise((resolve, reject) => {
    const sock = new WebSocket(url);
    const listeners = new Set();
    sock.addEventListener("message", (ev) => {
      let msg;
      try { msg = JSON.parse(typeof ev.data === "string" ? ev.data : ev.data.toString()); } catch (e) { return; }
      listeners.forEach((fn) => { try { fn(msg); } catch (e) {} });
    });
    sock.addEventListener("open", () => {
      resolve({
        raw: sock,
        send(obj) { sock.send(JSON.stringify(obj)); },
        onMessage(fn) { listeners.add(fn); return () => listeners.delete(fn); },
        close() { try { sock.close(); } catch (e) {} }
      });
    });
    sock.addEventListener("error", (e) => reject(new Error("ws error: " + (e && e.message ? e.message : "unknown"))));
  });
}

module.exports = { connectWS };
