/**
 * GOOGLE APPS SCRIPT — QC & TRADE-IN DILLAH PONSEL
 * 
 * Cara Pasang (Hanya 1 Menit):
 * 1. Buka https://script.google.com di browser dan login dengan akun Google toko.
 * 2. Klik "Proyek Baru" (New Project), beri nama "Webhook QC Dillah Ponsel".
 * 3. Hapus semua kode default, lalu tempelkan (paste) seluruh kode di file ini.
 * 4. (Opsional) Jika ingin notifikasi bot Telegram langsung bunyi ke HP:
 *    Isi TELEGRAM_BOT_TOKEN dan TELEGRAM_CHAT_ID di bawah ini.
 * 5. Klik tombol "Terapkan" (Deploy) -> "Penerapan Baru" (New Deployment).
 * 6. Pilih jenis: "Aplikasi Web" (Web App).
 *    - Jalankan sebagai: "Saya" (Me)
 *    - Yang memiliki akses: "Siapa saja" (Anyone) -> PENTING agar APK bisa mengirim data tanpa login.
 * 7. Klik "Terapkan", izinkan hak akses, lalu SALIN URL Aplikasi Web yang muncul.
 *    (Contoh: https://script.google.com/macros/s/AKfycb.../exec)
 * 8. Masukkan URL tersebut ke pengaturan di aplikasi Dillah Ponsel Katalog.
 */

// Konfigurasi Notifikasi Telegram (Opsional — kosongkan jika belum dipakai)
const TELEGRAM_BOT_TOKEN = ""; // Contoh: "123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"
const TELEGRAM_CHAT_ID   = ""; // Contoh: "491782072" atau ID Grup Toko

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.tryLock(10000);

  try {
    const rawData = e.postData.contents;
    const data = JSON.parse(rawData);

    // Buka atau buat Spreadsheet target
    let ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) {
      // Jika skrip berdiri sendiri (standalone), buat file baru di Google Drive
      const files = DriveApp.getFilesByName("Database QC & Trade-In Dillah Ponsel");
      if (files.hasNext()) {
        ss = SpreadsheetApp.open(files.next());
      } else {
        ss = SpreadsheetApp.create("Database QC & Trade-In Dillah Ponsel");
      }
    }

    let sheet = ss.getSheetByName("Data QC");
    if (!sheet) {
      sheet = ss.insertSheet("Data QC");
      // Format Header Tabel
      const headers = [
        "Waktu (WITA)", "Model HP", "Merk", "IMEI", "Serial Hardware",
        "RAM / ROM", "Kondisi MDM / Kredit", "Knox Warranty", "Siklus Baterai",
        "Kesehatan Baterai", "Suhu (°C)", "Tegangan (mV)", "Lokasi GPS",
        "Alamat / Maps", "Layar Touchscreen", "LCD Display", "Getar & Flash",
        "Tombol Fisik", "Audio Speaker & Mic", "Kamera", "Rekomendasi Grade",
        "Estimasi Taksiran HPP", "Nama Tester / Cabang", "Catatan Tambahan"
      ];
      sheet.appendRow(headers);
      sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold").setBackground("#1e293b").setFontColor("#ffffff");
      sheet.setFrozenRows(1);
    }

    const timestamp = data.timestamp || Utilities.formatDate(new Date(), "Asia/Makassar", "yyyy-MM-dd HH:mm:ss");
    const mapsLink = (data.latitude && data.longitude) 
      ? "https://www.google.com/maps?q=" + data.latitude + "," + data.longitude 
      : "-";

    const newRow = [
      timestamp,
      data.model || "-",
      data.brand || "-",
      data.imei || "-",
      data.serial || "-",
      (data.ram || "-") + " / " + (data.storage || "-"),
      data.mdmStatus || "AMAN",
      data.knoxWarranty || "0x0 (Resmi)",
      data.batteryCycles || "-",
      data.batteryHealth || "-",
      data.batteryTemp || "-",
      data.batteryVoltage || "-",
      (data.latitude && data.longitude) ? (data.latitude + ", " + data.longitude) : "-",
      mapsLink,
      data.testTouch || "PASS",
      data.testLcd || "PASS",
      data.testHardware || "PASS",
      data.testButtons || "PASS",
      data.testAudio || "PASS",
      data.testCamera || "PASS",
      data.recommendedGrade || "GRADE A",
      data.estimatedPrice || "-",
      data.tester || "Toko Mabuun",
      data.notes || "-"
    ];

    sheet.appendRow(newRow);

    // Kirim notifikasi bot Telegram jika token diisi
    if (TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID) {
      sendTelegramAlert(data, mapsLink, timestamp);
    }

    return ContentService.createTextOutput(JSON.stringify({
      status: "success",
      message: "Data QC berhasil disimpan ke Google Sheets",
      row: sheet.getLastRow(),
      spreadsheetUrl: ss.getUrl()
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}

function sendTelegramAlert(data, mapsLink, timestamp) {
  try {
    const isMdmDanger = data.mdmStatus && data.mdmStatus.indexOf("AMAN") === -1;
    const isKnoxVoid  = data.knoxWarranty && data.knoxWarranty.indexOf("0x0") === -1;

    let text = "📱 <b>LAPORAN QC & TRADE-IN — DILLAH PONSEL</b>\n";
    text += "━━━━━━━━━━━━━━━━━━━━━━━\n";
    text += "📅 <b>Waktu:</b> " + timestamp + " WITA\n";
    text += "👤 <b>Tester:</b> " + (data.tester || "Kasir") + "\n";
    if (mapsLink !== "-") {
      text += "📍 <b>Lokasi:</b> <a href=\"" + mapsLink + "\">Buka Google Maps</a>\n";
    }
    text += "\n[ <b>SPESIFIKASI UNIT</b> ]\n";
    text += "• <b>Model:</b> " + (data.brand || "") + " " + (data.model || "") + "\n";
    text += "• <b>IMEI:</b> <code>" + (data.imei || "Belum discan") + "</code>\n";
    text += "• <b>Serial:</b> <code>" + (data.serial || "-") + "</code>\n";
    text += "• <b>RAM/ROM:</b> " + (data.ram || "-") + " / " + (data.storage || "-") + "\n";

    text += "\n[ <b>KEAMANAN & HARDWARE</b> ]\n";
    text += "• <b>MDM/Cicilan:</b> " + (isMdmDanger ? "🔴 <b>" + data.mdmStatus + "</b>" : "🟢 AMAN") + "\n";
    text += "• <b>Knox Warranty:</b> " + (isKnoxVoid ? "🔴 <b>" + data.knoxWarranty + "</b>" : "🟢 0x0 Resmi") + "\n";
    text += "• <b>Siklus Baterai:</b> " + (data.batteryCycles || "-") + " siklus (" + (data.batteryHealth || "Baik") + ")\n";

    text += "\n[ <b>HASIL PENGETESAN</b> ]\n";
    text += "• Touch / LCD: " + (data.testTouch || "PASS") + " / " + (data.testLcd || "PASS") + "\n";
    text += "• Getar / Flash: " + (data.testHardware || "PASS") + "\n";
    text += "• Tombol / Audio: " + (data.testButtons || "PASS") + " / " + (data.testAudio || "PASS") + "\n";
    text += "• Kamera: " + (data.testCamera || "PASS") + "\n";

    text += "\n━━━━━━━━━━━━━━━━━━━━━━━\n";
    text += "🏷️ <b>GRADE: " + (data.recommendedGrade || "GRADE A") + "</b>\n";
    if (data.estimatedPrice) {
      text += "💰 <b>Estimasi HPP:</b> " + data.estimatedPrice + "\n";
    }

    const payload = {
      chat_id: TELEGRAM_CHAT_ID,
      text: text,
      parse_mode: "HTML",
      disable_web_page_preview: true
    };

    UrlFetchApp.fetch("https://api.telegram.org/bot" + TELEGRAM_BOT_TOKEN + "/sendMessage", {
      method: "post",
      contentType: "application/json",
      payload: JSON.stringify(payload)
    });
  } catch (e) {
    Logger.log("Telegram alert failed: " + e.toString());
  }
}
