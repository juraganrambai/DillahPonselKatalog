# Batasan Keamanan & Protokol Evolusi Mandiri (Dillah Ponsel Katalog)

Dokumen ini mendefinisikan batasan ketat (*guardrails*) untuk proses evolusi mandiri aplikasi `dillah-katalog-android`. Meskipun aplikasi tidak menyimpan kredensial atau data sensitif pengguna, batasan ini menjamin stabilitas fungsional, integritas kode, dan mencegah regresi pada operasional toko fisik.

---

## 1. Zero External CDN / Air-Gapped Assets
- **Aturan:** Seluruh pustaka JS, stylesheet CSS, gambar, dan aset pendukung WAJIB diunduh dan disimpan secara lokal di dalam folder `assets/`.
- **Larangan:** Dilarang menyisipkan tag `<script src="https://...">` ke server pihak ketiga yang tidak terverifikasi (mencegah *supply-chain poisoning* dan menjaga aplikasi tetap berfungsi 100% *offline*).
- **Whitelist Domain Keluar:**
  1. `https://wa.me` & intent WhatsApp (transaksi order & tukar tambah).
  2. `https://dillahponsel.store` (sinkronisasi data produk online).
  3. `https://cctv.tabalongkab.go.id` (live streaming CCTV Dishub Tabalong).
  4. `https://script.google.com` (Google Sheets sinkronisasi QC diagnosa).

## 2. Invarian Inti Bisnis (Zero Breaking Changes)
- **Aturan:** 6 modul navigasi utama tidak boleh dihapus atau dipecah:
  1. `HP Baru` (Katalog harga & pre-order).
  2. `HP Seken` (Daftar unit second ready toko).
  3. `Tukar Tambah` (Kalkulator selisih & simulasi cicilan).
  4. `Diagnostik` (QC layar, audio, mic, kamera, getar).
  5. `Sekitar` (Pantau CCTV Tabalong & POI lokal).
  6. `Toko` (Profil, lokasi Mabuun, kontak WhatsApp).
- **Konstanta Terlindungi:** `WA_NUMBER`, formula margin appraisal HP seken, dan struktur schema data di `assets/data/*.js` tidak boleh diubah/dihapus oleh bot evolusi.

## 3. Automated Quality Gate (Headless Smoke Test)
- **Aturan:** Sebelum APK dikompilasi, halaman `assets/index.html` harus lolos uji render otomatis via headless browser:
  - 0 unhandled JavaScript exceptions di console.
  - DOM navigation dock berhasil di-mount.
  - Waktu muat awal di bawah 1.500 ms.

## 4. Git Atomic Commit & Auto-Rollback
- **Aturan:** Setiap perubahan fitur diisolasi dalam 1 commit Git tersendiri dengan format `feat(evolution): [nama fitur]`.
- **Fail-Safe:** Jika pengujian headless atau perintah `build.sh` menghasilkan return code non-zero, sistem WAJIB melakukan `git reset --hard HEAD` seketika. Jangan pernah membiarkan kode rusak tersimpan.

## 5. Versioning & Delivery Gate
- **Aturan:** Setiap build sukses wajib menaikkan `versionCode` (+1) di `AndroidManifest.xml`.
- **Output:** File APK final diletakkan di `/Users/arsya/Desktop/DillahPonselKatalog.apk` dan notifikasi changelog dikirimkan ke Telegram operator.
