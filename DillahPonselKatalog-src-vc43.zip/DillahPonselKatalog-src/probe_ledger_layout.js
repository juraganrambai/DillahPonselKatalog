#!/usr/bin/env node
/**
 * Probe tata letak (layout) kartu Buku Taksiran Kasir.
 * Mengukur geometri nyata elemen: lebar/tinggi, overflow horizontal, tumpang tindih
 * antara canvas grafik dan kotak statistik/daftar, serta keterbacaan font.
 */
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");

const DIR = path.resolve(__dirname);
const PORT = 9600 + Math.floor(Math.random() * 300);
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const PAGE = "file://" + path.join(DIR, "assets", "index.html");
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function cdp(ws, method, params) {
  return new Promise((resolve, reject) => {
    const id = ++ws._id;
    const off = ws.onMessage((m) => {
      if (m.id === id) { off(); m.error ? reject(new Error(method + ": " + JSON.stringify(m.error))) : resolve(m.result); }
    });
    ws.send({ id, method, params: params || {} });
    setTimeout(() => { off(); reject(new Error("timeout " + method)); }, 30000);
  });
}
async function evalJS(ws, expr) {
  const res = await cdp(ws, "Runtime.evaluate", { expression: expr, awaitPromise: true, returnByValue: true });
  if (res.exceptionDetails) throw new Error("JS exception: " + JSON.stringify(res.exceptionDetails.exception || res.exceptionDetails.text));
  return res.result.value;
}

(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), "ledgerlayout_"));
  const chrome = spawn(CHROME, ["--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
    "--remote-debugging-port=" + PORT, "--user-data-dir=" + profile, "--allow-file-access-from-files",
    "--window-size=412,915", PAGE], { stdio: "ignore" });

  const out = {};
  let ws;
  try {
    let pageTarget = null;
    for (let i = 0; i < 60; i++) {
      try {
        const r = await fetch(`http://127.0.0.1:${PORT}/json/list`);
        const t = await r.json();
        pageTarget = t.find(x => x.type === "page" && x.url === PAGE && x.webSocketDebuggerUrl);
        if (pageTarget) break;
      } catch (e) {}
      await sleep(300);
    }
    if (!pageTarget) throw new Error("target tidak ditemukan");
    const { connectWS } = require("./wshelper.js");
    ws = await connectWS(pageTarget.webSocketDebuggerUrl);
    ws._id = 0;
    await cdp(ws, "Runtime.enable");
    await sleep(2600);

    // Seed data beragam lalu render
    await evalJS(ws, `(async () => {
      DillahLedger.clear();
      const now = Date.now();
      const seed = [
        ["iPhone 11 128GB", "iPhone 13 128GB", 4200000, 3610000, 0],
        ["Redmi Note 10", "Redmi Note 13", 1450000, 1180000, 1],
        ["Samsung A54 256GB", "Samsung A55 5G", 3100000, 2650000, 1],
        ["Oppo Reno 8", "Oppo Reno 11", 2750000, 2180000, 2],
        ["Vivo V29 256GB", "Vivo V30", 3600000, 3120000, 3],
        ["Realme 11 Pro", "Realme 12 Pro", 2400000, 1950000, 4],
        ["POCO X5 Pro", "POCO X6 Pro", 2050000, 1620000, 6],
        ["Infinix Note 30", "Infinix Note 40", 1350000, 980000, 9],
        ["Asus Zenfone 9", "Zenfone 10", 3900000, 3010000, 12]
      ];
      seed.forEach((s, i) => DillahLedger.upsert({
        kode: "DLH-TT-LAYOUT-" + i, namaLama: s[0], namaTujuan: s[1],
        pasaran: s[2], taksiran: s[3], selisih: 2000000,
        grade: "grade_a", sinyal: "resmi", kelengkapan: "fullset",
        ts: now - s[4] * 86400000
      }));
      const navItem = document.querySelectorAll(".nav-item")[2];
      if (navItem && window.onNavClick) window.onNavClick(navItem, 2);
      window.setLedgerRange(14);
      await new Promise(r => setTimeout(r, 500));
      return true;
    })()`);
    await sleep(900);

    out.layout = await evalJS(ws, `(() => {
      const rect = (sel) => {
        const el = document.querySelector(sel);
        if (!el) return null;
        const b = el.getBoundingClientRect();
        return { x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height) };
      };
      const card = document.getElementById("ledgerCard");
      const chartHost = document.getElementById("ledgerChart");
      const cv = chartHost ? chartHost.querySelector("canvas") : null;
      const stats = document.getElementById("ledgerStats");
      const recent = document.getElementById("ledgerRecentWrap");

      const cb = card.getBoundingClientRect();
      const sb = stats ? stats.getBoundingClientRect() : null;
      const rb = recent ? recent.getBoundingClientRect() : null;
      const cvb = cv ? cv.getBoundingClientRect() : null;

      // Tumpang tindih vertikal antar blok (harus 0)
      const overlap = (a, b) => (!a || !b) ? 0 : Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));

      const statCells = stats ? Array.from(stats.children).map(c => {
        const b = c.getBoundingClientRect();
        return { w: Math.round(b.width), h: Math.round(b.height) };
      }) : [];

      // Cek ada teks yang melampaui lebar kartu
      let overflowers = [];
      card.querySelectorAll("*").forEach(el => {
        if (el.scrollWidth > el.clientWidth + 1 && el.clientWidth > 0) {
          overflowers.push({ tag: el.tagName, id: el.id || "", sw: el.scrollWidth, cw: el.clientWidth });
        }
      });

      // Font terkecil di dalam kartu
      let minFont = 99;
      card.querySelectorAll("*").forEach(el => {
        const f = parseFloat(getComputedStyle(el).fontSize);
        if (f && f < minFont) minFont = f;
      });

      return {
        card: { w: Math.round(cb.width), h: Math.round(cb.height) },
        chartCanvas: cvb ? { w: Math.round(cvb.width), h: Math.round(cvb.height) } : null,
        chartFitsCard: cvb ? (cvb.width <= cb.width - 20) : null,
        statsCells: statCells,
        statsCount: statCells.length,
        overlapStatsChart: Math.round(overlap(sb, cvb)),
        overlapChartRecent: Math.round(overlap(cvb, rb)),
        overflowers: overflowers.slice(0, 6),
        minFontPx: minFont,
        docOverflowX: document.documentElement.scrollWidth > window.innerWidth + 1,
        recentRows: document.getElementById("ledgerRecentList").children.length
      };
    })()`);

    // Uji lebar sempit (320px) untuk memastikan tidak pecah di HP kecil
    await cdp(ws, "Emulation.setDeviceMetricsOverride", { width: 320, height: 800, deviceScaleFactor: 1, mobile: true });
    await sleep(400);
    await evalJS(ws, "window.setLedgerRange(7); true");
    await sleep(700);
    out.narrow = await evalJS(ws, `(() => {
      const cv = document.querySelector("#ledgerChart canvas");
      const card = document.getElementById("ledgerCard");
      const cb = card.getBoundingClientRect();
      let overflowers = [];
      card.querySelectorAll("*").forEach(el => {
        if (el.scrollWidth > el.clientWidth + 1 && el.clientWidth > 0) overflowers.push(el.tagName + "#" + (el.id || ""));
      });
      return {
        cardW: Math.round(cb.width),
        chartW: cv ? Math.round(cv.getBoundingClientRect().width) : null,
        chartFits: cv ? cv.getBoundingClientRect().width <= cb.width - 10 : null,
        docOverflowX: document.documentElement.scrollWidth > window.innerWidth + 1,
        overflowers: overflowers.slice(0, 5)
      };
    })()`);

  } catch (e) {
    out.fatal = e.message;
  } finally {
    try { if (ws) ws.close(); } catch (e) {}
    chrome.kill("SIGKILL");
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  }
  console.log(JSON.stringify(out, null, 2));
})();
