#!/usr/bin/env node
/** Tangkap screenshot sheet tanda tangan (Chrome headless via CDP) untuk inspeksi visual. */
const { spawn } = require("child_process");
const fs = require("fs"), path = require("path"), os = require("os");
const { connectWS } = require("./wshelper.js");

const DIR = path.resolve(__dirname);
const PORT = 9700 + Math.floor(Math.random() * 200);
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const PAGE = "file://" + path.join(DIR, "assets", "index.html");
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), "sigshot_"));
  const chrome = spawn(CHROME, ["--headless=new", "--disable-gpu", "--no-first-run",
    "--remote-debugging-port=" + PORT, "--user-data-dir=" + profile,
    "--allow-file-access-from-files", "--window-size=412,915", PAGE], { stdio: "ignore" });
  let ws, id = 0; const pend = new Map();
  try {
    let target = null;
    for (let i = 0; i < 60; i++) {
      try {
        const r = await fetch(`http://127.0.0.1:${PORT}/json/list`);
        target = (await r.json()).find(t => t.type === "page" && t.url === PAGE && t.webSocketDebuggerUrl);
        if (target) break;
      } catch (e) {}
      await sleep(300);
    }
    if (!target) throw new Error("target tidak ditemukan");
    ws = await connectWS(target.webSocketDebuggerUrl);
    ws.onMessage(m => { if (pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } });
    const send = (method, params) => new Promise((res, rej) => {
      const i = ++id; pend.set(i, m => m.error ? rej(new Error(JSON.stringify(m.error))) : res(m.result));
      ws.send({ id: i, method, params: params || {} }); setTimeout(() => rej(new Error("to " + method)), 20000);
    });
    const ev = async expr => {
      const r = await send("Runtime.evaluate", { expression: expr, awaitPromise: true, returnByValue: true });
      if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || "eval error");
      return r.result.value;
    };

    await send("Runtime.enable");
    for (let i = 0; i < 60; i++) {
      const ok = await ev(`(document.readyState==="complete" && typeof state==="object" && typeof DillahSignature==="object")`).catch(() => false);
      if (ok) break;
      await sleep(300);
    }

    await send("Emulation.setDeviceMetricsOverride", { width: 412, height: 915, deviceScaleFactor: 2, mobile: true });
    await ev(`(() => {
      state.currentTradeInVoucher = "DLH-TT-2611-4471";
      document.getElementById("boxVoucherBarcode").style.display = "block";
      document.getElementById("ttdStatusText").innerText = "Belum ditandatangani";
      window.refreshSignaturePreview();
      window.openSignatureSheet();
      return true;
    })()`);
    await sleep(700);

    // Gambar goresan contoh supaya screenshot memperlihatkan TTD asli
    await ev(`(() => {
      const c = document.getElementById("sigPadCanvas");
      const r = c.getBoundingClientRect();
      const pts = [[0.12,0.66],[0.20,0.34],[0.28,0.60],[0.36,0.30],[0.44,0.64],[0.52,0.36],[0.60,0.58],[0.70,0.40],[0.80,0.52]];
      const mk = (type, x, y, button) => c.dispatchEvent(new PointerEvent(type, {
        clientX: r.left + r.width * x, clientY: r.top + r.height * y,
        pointerId: 1, pointerType: "touch", isPrimary: true,
        button: button || 0, buttons: type === "pointerup" ? 0 : 1, bubbles: true, cancelable: true
      }));
      mk("pointerdown", pts[0][0], pts[0][1]);
      for (let i = 1; i < pts.length; i++) {
        const [ax, ay] = pts[i-1], [bx, by] = pts[i];
        for (let s = 1; s <= 8; s++) mk("pointermove", ax + (bx-ax)*s/8, ay + (by-ay)*s/8);
      }
      mk("pointerup", pts[pts.length-1][0], pts[pts.length-1][1]);
      return !sigPad.isEmpty();
    })()`);
    await sleep(500);

    const shot1 = await send("Page.captureScreenshot", { format: "png", fromSurface: true });
    const out1 = path.join(DIR, "selftest_sheet_ttd.png");
    fs.writeFileSync(out1, Buffer.from(shot1.data, "base64"));
    console.log("sheet:", out1, fs.statSync(out1).size, "bytes");

    // Simpan lalu screenshot blok voucher di tab Tukar
    await ev(`(() => { document.getElementById("sigNamaInput").value = "Budi Santoso"; window.saveSignaturePad(); return true; })()`);
    await sleep(600);
    await ev(`(() => {
      window.onNavClick(document.querySelector('.nav-item[data-idx="2"]'), 2);
      return true;
    })()`);
    await sleep(800);
    // scroll ke box voucher
    await ev(`(() => { const el = document.getElementById("boxVoucherBarcode"); if (el) el.scrollIntoView({block:"center"}); return true; })()`);
    await sleep(500);
    const shot2 = await send("Page.captureScreenshot", { format: "png", fromSurface: true });
    const out2 = path.join(DIR, "selftest_voucher_ttd.png");
    fs.writeFileSync(out2, Buffer.from(shot2.data, "base64"));
    console.log("voucher:", out2, fs.statSync(out2).size, "bytes");
  } catch (e) {
    console.log("ERROR:", e.message);
    process.exitCode = 1;
  } finally {
    try { ws && ws.close(); } catch (e) {}
    chrome.kill("SIGKILL");
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  }
})();
