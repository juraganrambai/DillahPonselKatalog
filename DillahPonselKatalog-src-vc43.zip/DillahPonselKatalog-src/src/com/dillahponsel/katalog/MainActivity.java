package com.dillahponsel.katalog;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.provider.Settings;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import android.content.pm.PackageInfo;
import java.lang.reflect.Method;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

public class MainActivity extends Activity {
    private WebView webView;
    private Vibrator vibrator;
    private CameraManager cameraManager;
    private String cameraIdWithFlash = null;
    private boolean isListeningHardwareKeys = false;
    private LocationManager locationManager;
    private Location lastKnownLoc = null;

    private static final String PREFS_NAME = "DillahQcPrefs";
    private static final String KEY_WEBHOOK_URL = "webhook_url";
    private static final String KEY_INITIAL_SENT_PREFIX = "initial_sent_";
    
    // Default Webhook Google Apps Script (bisa diubah dari UI pengaturan di WebView)
    public static final String DEFAULT_WEBHOOK_URL = "https://script.google.com/macros/s/AKfycbw_DILLAH_QC_DEFAULT/exec";

    private static final String[] PROXY_HOSTS = {
            "cctv.tabalongkab.go.id",
            "dillahponsel.store",
            "detik.com",
            "inet.detik.com",
            "rss.detik.com"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            if (vm != null) {
                vibrator = vm.getDefaultVibrator();
            }
        }
        if (vibrator == null) {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        initCameraManager();

        webView = new WebView(this);
        WebView.setWebContentsDebuggingEnabled(true);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setLoadsImagesAutomatically(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setUserAgentString(ws.getUserAgentString() + " DillahApp/1.5");
        ws.setMediaPlaybackRequiresUserGesture(false);

        CookieManager cm = new CookieManager();
        CookieHandler.setDefault(cm);
        android.webkit.CookieManager.getInstance().setAcceptCookie(true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    try {
                        request.grant(request.getResources());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                return super.onConsoleMessage(cm);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host != null) {
                    for (String h : PROXY_HOSTS) {
                        if (h.equalsIgnoreCase(host)) {
                            return proxyFetch(request);
                        }
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            private boolean handleUrl(String url) {
                if (url.startsWith("whatsapp:") || url.contains("api.whatsapp.com") || url.contains("wa.me")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Aplikasi WhatsApp tidak ditemukan", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                } else if (url.startsWith("tel:")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        return false;
                    }
                } else if (url.startsWith("rawbt:")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Aplikasi RawBT Printer belum terpasang", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                } else if (url.startsWith("http://") || url.startsWith("https://")) {
                    if (!url.contains("dillahponsel.store") && !url.contains("localhost")) {
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                            startActivity(intent);
                            return true;
                        } catch (Exception e) {
                            return false;
                        }
                    }
                }
                return false;
            }
        });

        webView.addJavascriptInterface(new DiagnosticBridge(), "AndroidDiag");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);

        // Minta semua izin di awal saat aplikasi pertama kali dibuka / dipasang
        checkAndRequestAllPermissions();
    }

    private WebResourceResponse proxyFetch(WebResourceRequest request) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(request.getUrl().toString());
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(20000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36 DillahApp/1.5");
            conn.setRequestProperty("Accept", "*/*");
            conn.setRequestProperty("Origin", "https://cctv.tabalongkab.go.id");
            conn.setRequestProperty("Referer", "https://cctv.tabalongkab.go.id/");

            Map<String, String> reqHeaders = request.getRequestHeaders();
            if (reqHeaders != null) {
                for (Map.Entry<String, String> e : reqHeaders.entrySet()) {
                    String k = e.getKey();
                    if (k == null) continue;
                    String lk = k.toLowerCase();
                    if (lk.equals("host") || lk.equals("origin") || lk.equals("referer")
                            || lk.equals("cookie") || lk.equals("accept-encoding")
                            || lk.equals("connection")) continue;
                    conn.setRequestProperty(k, e.getValue());
                }
            }

            int code = conn.getResponseCode();
            String ctype = conn.getContentType();
            String mime = "application/octet-stream";
            String charset = null;
            if (ctype != null) {
                String[] parts = ctype.split(";");
                mime = parts[0].trim();
                for (String p : parts) {
                    if (p.trim().toLowerCase().startsWith("charset=")) {
                        charset = p.trim().substring(8).trim();
                    }
                }
            }
            if (mime.isEmpty()) mime = "application/octet-stream";

            Map<String, String> respHeaders = new HashMap<>();
            respHeaders.put("Access-Control-Allow-Origin", "*");
            respHeaders.put("Cache-Control", "no-cache");

            InputStream stream = (code >= 200 && code < 300)
                    ? conn.getInputStream()
                    : conn.getErrorStream();

            int status = code;
            String reason = conn.getResponseMessage();
            if (stream != null) {
                return new WebResourceResponse(mime, charset, status, reason == null ? "" : reason,
                        respHeaders, stream);
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            if (conn != null) conn.disconnect();
            return null;
        }
    }

    private void initCameraManager() {
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager != null) {
                for (String id : cameraManager.getCameraIdList()) {
                    CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                    Boolean flashAvailable = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    if (flashAvailable != null && flashAvailable &&
                        facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                        cameraIdWithFlash = id;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void checkAndRequestAllPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] perms = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.READ_PHONE_STATE
            };
            boolean needReq = false;
            for (String p : perms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    needReq = true;
                    break;
                }
            }
            if (needReq) {
                requestPermissions(perms, 101);
            } else {
                startGpsAndSendInitialData();
            }
        } else {
            startGpsAndSendInitialData();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            // Setelah user menyetujui izin, otomatis trigger penangkapan GPS dan kirim data awal
            startGpsAndSendInitialData();
        }
    }

    private void startGpsAndSendInitialData() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    if (locationManager != null) {
                        lastKnownLoc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        if (lastKnownLoc == null) {
                            lastKnownLoc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        }
                        // Minta 1 update lokasi single shot
                        locationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, new LocationListener() {
                            @Override
                            public void onLocationChanged(Location location) {
                                lastKnownLoc = location;
                            }
                            @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                            @Override public void onProviderEnabled(String provider) {}
                            @Override public void onProviderDisabled(String provider) {}
                        }, Looper.getMainLooper());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Jalankan pengiriman data awal otomatis 2 detik setelah buka aplikasi
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            new Thread(() -> autoSendInitialData()).start();
        }, 2500);
    }

    private void autoSendInitialData() {
        try {
            DiagnosticBridge bridge = new DiagnosticBridge();
            String serial = bridge.getHardwareSerial();
            SharedPreferences sp = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String url = sp.getString(KEY_WEBHOOK_URL, DEFAULT_WEBHOOK_URL);

            JSONObject obj = new JSONObject();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));
            obj.put("timestamp", sdf.format(new Date()) + " WITA");
            obj.put("stage", "AWAL (Sebelum Pengecekan)");
            obj.put("brand", Build.BRAND);
            obj.put("model", Build.MODEL);
            obj.put("serial", serial);
            obj.put("imei", bridge.getImei());
            obj.put("androidVersion", Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")");

            JSONObject mdm = new JSONObject(bridge.getMdmStatus());
            obj.put("mdmStatus", mdm.optString("details", "AMAN"));
            obj.put("knoxWarranty", bridge.getKnoxWarranty());
            obj.put("batteryCycles", bridge.getBatteryCycleCount());

            // Battery Info
            JSONObject bat = new JSONObject(bridge.getBatteryInfo());
            obj.put("batteryHealth", bat.optString("health", "Baik") + " (" + bat.optInt("level", 0) + "%)");
            obj.put("batteryTemp", bat.optString("tempC", "-") + " °C");
            obj.put("batteryVoltage", bat.optInt("voltageMv", 0) + " mV");

            // RAM & Storage
            JSONObject dev = new JSONObject(bridge.getDeviceInfo());
            obj.put("ram", dev.optString("totalRamGb", "-") + " GB");
            obj.put("storage", dev.optString("totalStorageGb", "-") + " GB");

            // GPS Lokasi
            if (lastKnownLoc != null) {
                obj.put("latitude", lastKnownLoc.getLatitude());
                obj.put("longitude", lastKnownLoc.getLongitude());
            }

            obj.put("testTouch", "BELUM DITES");
            obj.put("testLcd", "BELUM DITES");
            obj.put("testHardware", "BELUM DITES");
            obj.put("testButtons", "BELUM DITES");
            obj.put("testAudio", "BELUM DITES");
            obj.put("testCamera", "BELUM DITES");
            obj.put("recommendedGrade", "DATA AWAL");
            obj.put("notes", "Otomatis dikirim saat aplikasi pertama dibuka");
            obj.put("tester", "Sistem Otomatis Dillah");

            bridge.submitQcReport(obj.toString(), url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            int code = event.getKeyCode();
            if (code == KeyEvent.KEYCODE_VOLUME_UP) {
                webView.evaluateJavascript("if(window.onDiagnosticKey) { window.onDiagnosticKey('VOLUME_UP'); }", null);
                if (isListeningHardwareKeys) return true;
            } else if (code == KeyEvent.KEYCODE_VOLUME_DOWN) {
                webView.evaluateJavascript("if(window.onDiagnosticKey) { window.onDiagnosticKey('VOLUME_DOWN'); }", null);
                if (isListeningHardwareKeys) return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressed() {
        closeCctvIfOpen();
    }

    private void closeCctvIfOpen() {
        if (webView == null) return;
        webView.evaluateJavascript(
                "(function(){var p=document.getElementById('cctvPlayer');" +
                "if(p&&p.classList.contains('show')&&typeof closeCctv==='function'){closeCctv();return 1;}return 0;})()",
                value -> {
                    if (!"1".equals(value)) {
                        if (webView.canGoBack()) webView.goBack(); else finish();
                    }
                });
    }

    // ─── DIAGNOSTIC JAVASCRIPT BRIDGE ───
    public class DiagnosticBridge {
        @JavascriptInterface
        public boolean isM360Installed() {
            return false;
        }

        @JavascriptInterface
        public boolean launchM360() {
            return false;
        }

        @JavascriptInterface
        public String getAppVersionInfo() {
            try {
                PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                JSONObject obj = new JSONObject();
                obj.put("versionCode", pInfo.versionCode);
                obj.put("versionName", pInfo.versionName);
                obj.put("packageName", getPackageName());
                return obj.toString();
            } catch (Exception e) {
                return "{\"versionCode\":9,\"versionName\":\"1.6.1\"}";
            }
        }

        private static final String TG_BOT_TOKEN = "8833644871:AAH8bLp1-f8oWl4Z19-bZ4N40Rj4gNdT_js";
        private static final String TG_CHAT_ID = "491782072";

        @JavascriptInterface
        public void fetchDetikTeknoNews() {
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL("https://rss.detik.com/index.php/inet");
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(10000);
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) DillahPonsel/1.6");
                    conn.connect();

                    if (conn.getResponseCode() == 200) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line).append("\n");
                        }
                        reader.close();

                        String xml = sb.toString();
                        final StringBuilder json = new StringBuilder("[");
                        java.util.regex.Pattern itemPat = java.util.regex.Pattern.compile("<item>(.*?)</item>", java.util.regex.Pattern.DOTALL);
                        java.util.regex.Matcher itemMat = itemPat.matcher(xml);

                        int count = 0;
                        while (itemMat.find() && count < 8) {
                            String itemXml = itemMat.group(1);
                            String title = extractTag(itemXml, "title");
                            String link = extractTag(itemXml, "link");
                            String pubDate = extractTag(itemXml, "pubDate");
                            String desc = extractTag(itemXml, "description");

                            desc = desc.replaceAll("<[^>]*>", "").replaceAll("\\s+", " ").trim();
                            if (desc.length() > 140) desc = desc.substring(0, 137) + "…";

                            if (count > 0) json.append(",");
                            json.append("{")
                                .append("\"title\":").append(org.json.JSONObject.quote(title)).append(",")
                                .append("\"link\":").append(org.json.JSONObject.quote(link)).append(",")
                                .append("\"date\":").append(org.json.JSONObject.quote(pubDate)).append(",")
                                .append("\"desc\":").append(org.json.JSONObject.quote(desc))
                                .append("}");
                            count++;
                        }
                        json.append("]");

                        final String finalJson = json.toString();
                        runOnUiThread(() -> {
                            if (webView != null) {
                                webView.evaluateJavascript("if (typeof window.onDetikTeknoNewsLoaded === 'function') { window.onDetikTeknoNewsLoaded(" + finalJson + "); }", null);
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }).start();
        }

        private String extractTag(String src, String tag) {
            try {
                java.util.regex.Pattern p = java.util.regex.Pattern.compile("<" + tag + ">(?:<\\!\\[CDATA\\[(.*?)\\]\\]>|(.*?))</" + tag + ">", java.util.regex.Pattern.DOTALL);
                java.util.regex.Matcher m = p.matcher(src);
                if (m.find()) {
                    String val = m.group(1) != null ? m.group(1) : m.group(2);
                    return val != null ? val.trim() : "";
                }
            } catch (Exception ignored) {}
            return "";
        }

        @JavascriptInterface
        public void checkTelegramUpdate(final boolean showToastIfLatest) {
            new Thread(() -> {
                try {
                    PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                    final int currentVersionCode = pInfo.versionCode;
                    final String currentVersionName = pInfo.versionName;

                    URL url = new URL("https://api.telegram.org/bot" + TG_BOT_TOKEN + "/getChat?chat_id=" + TG_CHAT_ID);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);
                    conn.setRequestProperty("User-Agent", "DillahPonsel/1.0");

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();

                    JSONObject res = new JSONObject(sb.toString());
                    if (!res.optBoolean("ok")) {
                        if (showToastIfLatest) {
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Tidak dapat memeriksa rilis Telegram.", Toast.LENGTH_SHORT).show());
                        }
                        return;
                    }

                    JSONObject resultObj = res.optJSONObject("result");
                    JSONObject pinned = resultObj != null ? resultObj.optJSONObject("pinned_message") : null;
                    if (pinned == null) {
                        if (showToastIfLatest) {
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Belum ada rilis pembaruan di Telegram.", Toast.LENGTH_SHORT).show());
                        }
                        return;
                    }

                    JSONObject doc = pinned.optJSONObject("document");
                    String caption = pinned.optString("caption", "");
                    if (doc == null) {
                        if (showToastIfLatest) {
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Rilis di Telegram tidak memiliki file APK.", Toast.LENGTH_SHORT).show());
                        }
                        return;
                    }

                    int remoteVc = 0;
                    String remoteVn = currentVersionName;
                    java.util.regex.Matcher mVc = java.util.regex.Pattern.compile("versionCode=(\\d+)").matcher(caption);
                    if (mVc.find()) {
                        remoteVc = Integer.parseInt(mVc.group(1));
                    }
                    java.util.regex.Matcher mVn = java.util.regex.Pattern.compile("versionName=([0-9a-zA-Z._-]+)").matcher(caption);
                    if (mVn.find()) {
                        remoteVn = mVn.group(1);
                    }

                    if (remoteVc > currentVersionCode) {
                        String fileId = doc.optString("file_id");
                        long fileSize = doc.optLong("file_size", 0);
                        String sizeStr = fileSize > 0 ? (fileSize / 1024) + " KB" : "~300 KB";

                        URL getFileUrl = new URL("https://api.telegram.org/bot" + TG_BOT_TOKEN + "/getFile?file_id=" + fileId);
                        HttpURLConnection fConn = (HttpURLConnection) getFileUrl.openConnection();
                        fConn.setConnectTimeout(10000);
                        fConn.setReadTimeout(10000);
                        BufferedReader fReader = new BufferedReader(new InputStreamReader(fConn.getInputStream(), StandardCharsets.UTF_8));
                        StringBuilder fSb = new StringBuilder();
                        while ((line = fReader.readLine()) != null) fSb.append(line);
                        fReader.close();

                        JSONObject fRes = new JSONObject(fSb.toString());
                        String filePath = fRes.optJSONObject("result") != null ? fRes.optJSONObject("result").optString("file_path") : "";
                        String directDownloadUrl = !filePath.isEmpty() ? "https://api.telegram.org/file/bot" + TG_BOT_TOKEN + "/" + filePath : "";

                        final int targetVc = remoteVc;
                        final String targetVn = remoteVn;
                        final String targetDl = directDownloadUrl;
                        final String targetSize = sizeStr;
                        final String safeCaption = caption.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");

                        runOnUiThread(() -> {
                            String js = "window.onTelegramUpdateFound && window.onTelegramUpdateFound("
                                + targetVc + ", '" + targetVn + "', '" + targetDl + "', '" + targetSize + "', \"" + safeCaption + "\");";
                            webView.evaluateJavascript(js, null);
                        });
                    } else {
                        if (showToastIfLatest) {
                            final String curVn = currentVersionName;
                            final int curVc = currentVersionCode;
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Aplikasi sudah versi terbaru (v" + curVn + " Build " + curVc + ")", Toast.LENGTH_SHORT).show());
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    if (showToastIfLatest) {
                        final String msg = e.getMessage() != null ? e.getMessage() : "Koneksi gagal";
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gagal cek update: " + msg, Toast.LENGTH_SHORT).show());
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void triggerForceUpdate(final String downloadUrl) {
            new Thread(() -> {
                try {
                    File cacheDir = getCacheDir();
                    File apkFile = new File(cacheDir, "dillah_katalog_update.apk");
                    if (apkFile.exists()) apkFile.delete();

                    if (downloadUrl != null && (downloadUrl.startsWith("http://") || downloadUrl.startsWith("https://"))) {
                        URL url = new URL(downloadUrl);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setConnectTimeout(15000);
                        conn.setReadTimeout(30000);
                        conn.setRequestProperty("User-Agent", "DillahPonsel/1.0");
                        conn.connect();

                        int totalSize = conn.getContentLength();
                        InputStream in = conn.getInputStream();
                        FileOutputStream out = new FileOutputStream(apkFile);
                        byte[] buffer = new byte[8192];
                        int read;
                        int downloaded = 0;
                        int lastReportedPct = -1;
                        while ((read = in.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                            downloaded += read;
                            if (totalSize > 0) {
                                final int pct = (int) ((downloaded * 100L) / totalSize);
                                if (pct != lastReportedPct) {
                                    lastReportedPct = pct;
                                    runOnUiThread(() -> {
                                        webView.evaluateJavascript("window.onUpdateDownloadProgress && window.onUpdateDownloadProgress(" + pct + ");", null);
                                    });
                                }
                            }
                        }
                        out.flush();
                        out.close();
                        in.close();
                    }

                    runOnUiThread(() -> {
                        webView.evaluateJavascript("window.onUpdateDownloadProgress && window.onUpdateDownloadProgress(100);", null);
                    });

                    installApkFile(apkFile);
                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gagal mengunduh pembaruan: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }).start();
        }

        @JavascriptInterface
        public void installLocalApk(final String filePath) {
            try {
                File file = new File(filePath);
                installApkFile(file);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void installApkFile(final File apkFile) {
            runOnUiThread(() -> {
                try {
                    if (!apkFile.exists()) {
                        Toast.makeText(MainActivity.this, "File APK tidak ditemukan", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Try root silent update first if device is rooted
                    try {
                        Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "pm install -r -d " + apkFile.getAbsolutePath()});
                        if (p.waitFor() == 0) {
                            Toast.makeText(MainActivity.this, "Pembaruan otomatis berhasil dipasang!", Toast.LENGTH_SHORT).show();
                            Intent intent = getPackageManager().getLaunchIntentForPackage(getPackageName());
                            if (intent != null) {
                                startActivity(intent);
                                finish();
                            }
                            return;
                        }
                    } catch (Exception ignored) {}

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (!getPackageManager().canRequestPackageInstalls()) {
                            Toast.makeText(MainActivity.this, "Izinkan instalasi aplikasi untuk melanjutkan pembaruan", Toast.LENGTH_LONG).show();
                            Intent manageIntent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                            startActivity(manageIntent);
                            return;
                        }
                    }

                    // Standard Package Installer via GenericFileProvider
                    Uri contentUri = Uri.parse("content://" + getPackageName() + ".fileprovider" + apkFile.getAbsolutePath());
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(contentUri, "application/vnd.android.package-archive");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Gagal membuka installer: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public String getKnoxStatus() {
            return getKnoxWarranty();
        }

        @JavascriptInterface
        public int getBatteryCycle() {
            return getBatteryCycleCount();
        }

        @JavascriptInterface
        public boolean isAppInstalled(String packageName) {
            if (packageName == null || packageName.isEmpty()) return false;
            try {
                getPackageManager().getPackageInfo(packageName, 0);
                return true;
            } catch (PackageManager.NameNotFoundException e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean launchApp(String packageName) {
            if (packageName == null || packageName.isEmpty()) return false;
            try {
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launchIntent);
                    return true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }

        @JavascriptInterface
        public String getInstalledStoreApps() {
            try {
                JSONObject obj = new JSONObject();
                obj.put("m360", isAppInstalled("com.atlassoft.m360"));
                obj.put("whatsapp", isAppInstalled("com.whatsapp"));
                obj.put("whatsapp_business", isAppInstalled("com.whatsapp.w4b"));
                obj.put("rawbt_print", isAppInstalled("ru.a402d.rawbtprinter"));
                obj.put("qasir", isAppInstalled("com.qasir"));
                obj.put("mokapos", isAppInstalled("com.mokapos"));
                obj.put("dillah_katalog", true);
                return obj.toString();
            } catch (Exception e) {
                return "{}";
            }
        }


        private final Set<String> WHITELISTED_ADMINS = new HashSet<>(Arrays.asList(
                "com.dillahponsel.katalog",
                "com.atlassoft.m360",
                "com.afwsamples.testdpc",
                "com.google.android.apps.work.clouddpc"
        ));

        private final Set<String> MDM_KNOWN_BLACKLST = new HashSet<>(Arrays.asList(
                "com.payjoy.access",
                "com.payjoy.status",
                "com.sec.enterprise.knox.cloudmdm.smdms",
                "com.samsung.ucs.agent.boot",
                "com.microsoft.windowsintune.companyportal",
                "com.airwatch.androidagent",
                "com.mobileiron",
                "com.fiberlink.maas360.android.sysadmin",
                "com.kredivo",
                "id.co.homecredit"
        ));

        @JavascriptInterface
        public void setHardwareKeyListenerActive(boolean active) {
            isListeningHardwareKeys = active;
        }

        @JavascriptInterface
        public void setFullscreen(boolean enable) {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        WindowInsetsController controller = getWindow().getInsetsController();
                        if (controller != null) {
                            if (enable) {
                                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                            } else {
                                controller.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                            }
                        }
                    } else {
                        View decorView = getWindow().getDecorView();
                        if (enable) {
                            decorView.setSystemUiVisibility(
                                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                            );
                        } else {
                            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            JSONObject obj = new JSONObject();
            try {
                obj.put("brand", Build.BRAND);
                obj.put("manufacturer", Build.MANUFACTURER);
                obj.put("model", Build.MODEL);
                obj.put("device", Build.DEVICE);
                obj.put("board", Build.BOARD);
                obj.put("hardware", Build.HARDWARE);
                obj.put("androidVersion", Build.VERSION.RELEASE);
                obj.put("sdkInt", Build.VERSION.SDK_INT);
                obj.put("serial", getHardwareSerial());
                obj.put("imei", getImei());
                obj.put("knoxWarranty", getKnoxWarranty());
                obj.put("batteryCycles", getBatteryCycleCount());

                JSONObject mdm = new JSONObject(getMdmStatus());
                obj.put("isMdm", mdm.optBoolean("isMdm", false));
                obj.put("mdmDetails", mdm.optString("details", "AMAN"));

                ActivityManager actManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
                if (actManager != null) {
                    actManager.getMemoryInfo(memInfo);
                    double totalRamGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0);
                    double availRamGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0);
                    obj.put("totalRamGb", String.format("%.1f", totalRamGb));
                    obj.put("availRamGb", String.format("%.1f", availRamGb));
                }

                File path = Environment.getDataDirectory();
                StatFs stat = new StatFs(path.getPath());
                long blockSize = stat.getBlockSizeLong();
                long totalBlocks = stat.getBlockCountLong();
                long availableBlocks = stat.getAvailableBlocksLong();
                double totalStorageGb = (totalBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0);
                double freeStorageGb = (availableBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0);
                obj.put("totalStorageGb", String.format("%.1f", totalStorageGb));
                obj.put("freeStorageGb", String.format("%.1f", freeStorageGb));

            } catch (Exception e) {
                e.printStackTrace();
            }
            return obj.toString();
        }

        @JavascriptInterface
        public String getBatteryInfo() {
            JSONObject obj = new JSONObject();
            try {
                IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                Intent batteryStatus = registerReceiver(null, ifilter);

                if (batteryStatus != null) {
                    int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
                    int temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                    int voltage = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                    int plugged = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);

                    int pct = (int) ((level / (float) scale) * 100);
                    obj.put("level", pct);

                    String statusStr = "Discharging";
                    if (status == BatteryManager.BATTERY_STATUS_CHARGING) statusStr = "Charging";
                    else if (status == BatteryManager.BATTERY_STATUS_FULL) statusStr = "Penuh";
                    obj.put("status", statusStr);

                    String healthStr = "Baik";
                    if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT) healthStr = "Overheat";
                    else if (health == BatteryManager.BATTERY_HEALTH_DEAD) healthStr = "Rusak";
                    else if (health == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) healthStr = "Over Voltage";
                    obj.put("health", healthStr);

                    obj.put("tempC", String.format("%.1f", temp / 10.0));
                    obj.put("voltageMv", voltage);
                    obj.put("isPlugged", plugged > 0);
                    obj.put("cycles", getBatteryCycleCount());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return obj.toString();
        }

        @JavascriptInterface
        public String getKnoxWarranty() {
            try {
                Class<?> spClass = Class.forName("android.os.SystemProperties");
                Method getMethod = spClass.getMethod("get", String.class, String.class);
                String wb = (String) getMethod.invoke(null, "ro.boot.warranty_bit", "0");
                if ("0".equals(wb)) {
                    wb = (String) getMethod.invoke(null, "ro.warranty_bit", "0");
                }
                return "1".equals(wb) ? "0x1 (Void / Modif)" : "0x0 (Resmi / Utuh)";
            } catch (Exception e) {
                return "0x0 (Standar)";
            }
        }

        @JavascriptInterface
        public String getHardwareSerial() {
            try {
                Class<?> spClass = Class.forName("android.os.SystemProperties");
                Method getMethod = spClass.getMethod("get", String.class, String.class);
                String s = (String) getMethod.invoke(null, "ro.serialno", "");
                if (s != null && !s.isEmpty()) return s;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        return Build.getSerial();
                    }
                }
            } catch (Exception e) {}
            return Build.SERIAL != null ? Build.SERIAL : "-";
        }

        @JavascriptInterface
        public String getImei() {
            try {
                Class<?> spClass = Class.forName("android.os.SystemProperties");
                Method getMethod = spClass.getMethod("get", String.class, String.class);
                String imei1 = (String) getMethod.invoke(null, "ril.serialnumber", "");
                if (imei1 != null && !imei1.isEmpty()) return imei1;
                imei1 = (String) getMethod.invoke(null, "ro.ril.oem.imei", "");
                if (imei1 != null && !imei1.isEmpty()) return imei1;
            } catch (Exception ignored) {}
            return "Scan Barcode";
        }

        @JavascriptInterface
        public int getBatteryCycleCount() {
            String[] paths = {
                    "/sys/class/power_supply/battery/battery_cycle",
                    "/sys/class/power_supply/battery/cycle_count",
                    "/sys/class/power_supply/sec/battery/cycle",
                    "/sys/class/power_supply/battery/fg_cycle"
            };
            for (String p : paths) {
                try {
                    File f = new File(p);
                    if (f.exists() && f.canRead()) {
                        BufferedReader br = new BufferedReader(new FileReader(f));
                        String line = br.readLine();
                        br.close();
                        if (line != null) {
                            int c = Integer.parseInt(line.trim());
                            if (c >= 0) return c;
                        }
                    }
                } catch (Exception ignored) {}
            }
            return -1;
        }

        /**
         * Logika MDM Checker standar M360 asli (presisi tanpa false positive)
         */
        @JavascriptInterface
        public String getMdmStatus() {
            JSONObject res = new JSONObject();
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                boolean isMdm = false;
                StringBuilder details = new StringBuilder();

                // Daftar paket leasing/MDM blacklist internasional dan lokal Indonesia
                Set<String> badPackages = new HashSet<>(Arrays.asList(
                        "com.payjoy.access",
                        "com.payjoy.status",
                        "com.microsoft.windowsintune.companyportal",
                        "com.airwatch.androidagent",
                        "com.mobileiron",
                        "com.fiberlink.maas360.android.control",
                        "com.rim.mobilefusion.client",
                        "id.co.homecredit.myhomecredit",
                        "com.kredivo"
                ));

                if (dpm != null) {
                    List<ComponentName> admins = dpm.getActiveAdmins();
                    if (admins != null && !admins.isEmpty()) {
                        for (ComponentName cn : admins) {
                            String pkg = cn.getPackageName();
                            if (pkg.equals(getPackageName()) || pkg.equals("com.atlassoft.m360")) continue;

                            boolean isDeviceOwner = dpm.isDeviceOwnerApp(pkg);
                            boolean isProfileOwner = dpm.isProfileOwnerApp(pkg);

                            if (isDeviceOwner) {
                                isMdm = true;
                                details.append("Device Owner Aktif: ").append(pkg).append("; ");
                            } else if (isProfileOwner && Build.VERSION.SDK_INT >= 30 && dpm.isOrganizationOwnedDeviceWithManagedProfile()) {
                                isMdm = true;
                                details.append("Managed Org Profile: ").append(pkg).append("; ");
                            } else if (badPackages.contains(pkg)) {
                                isMdm = true;
                                details.append("Leasing Aktif: ").append(pkg).append("; ");
                            }
                        }
                    }
                }

                // Cek status Samsung Knox Guard (KG status) via System Properties
                try {
                    Class<?> spClass = Class.forName("android.os.SystemProperties");
                    Method getMethod = spClass.getMethod("get", String.class, String.class);
                    String kgBit = (String) getMethod.invoke(null, "ro.boot.kg.bit", "00");
                    if ("01".equals(kgBit) || "1".equals(kgBit)) {
                        isMdm = true;
                        details.append("Knox Guard Terkunci (Bit: ").append(kgBit).append("); ");
                    }
                } catch (Exception ignored) {}

                // Scan paket leasing terpasang
                PackageManager pm = getPackageManager();
                for (String badPkg : badPackages) {
                    try {
                        pm.getPackageInfo(badPkg, 0);
                        isMdm = true;
                        details.append("Paket Cicilan Terpasang: ").append(badPkg).append("; ");
                    } catch (PackageManager.NameNotFoundException ignored) {}
                }

                res.put("isMdm", isMdm);
                res.put("details", isMdm ? details.toString().trim() : "AMAN (Bebas Cicilan & Bebas MDM)");
            } catch (Exception e) {
                try {
                    res.put("isMdm", false);
                    res.put("details", "Gagal cek: " + e.getMessage());
                } catch (Exception ignored) {}
            }
            return res.toString();
        }

        @JavascriptInterface
        public String getLocation() {
            JSONObject locObj = new JSONObject();
            try {
                if (lastKnownLoc != null) {
                    locObj.put("latitude", lastKnownLoc.getLatitude());
                    locObj.put("longitude", lastKnownLoc.getLongitude());
                    locObj.put("accuracy", lastKnownLoc.getAccuracy());
                    locObj.put("provider", lastKnownLoc.getProvider());
                    return locObj.toString();
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        locObj.put("error", "Izin GPS belum diizinkan");
                        return locObj.toString();
                    }
                }

                if (locationManager != null) {
                    Location loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (loc == null) loc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (loc != null) {
                        lastKnownLoc = loc;
                        locObj.put("latitude", loc.getLatitude());
                        locObj.put("longitude", loc.getLongitude());
                        locObj.put("accuracy", loc.getAccuracy());
                        locObj.put("provider", loc.getProvider());
                        return locObj.toString();
                    }
                }
                locObj.put("error", "Sinyal GPS belum terkunci");
            } catch (Exception e) {
                try { locObj.put("error", e.getMessage()); } catch (Exception ignored) {}
            }
            return locObj.toString();
        }

        @JavascriptInterface
        public String getWebhookUrl() {
            SharedPreferences sp = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            return sp.getString(KEY_WEBHOOK_URL, DEFAULT_WEBHOOK_URL);
        }

        @JavascriptInterface
        public void setWebhookUrl(String url) {
            SharedPreferences sp = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            sp.edit().putString(KEY_WEBHOOK_URL, url != null ? url.trim() : DEFAULT_WEBHOOK_URL).apply();
        }

        @JavascriptInterface
        public String submitQcReport(String jsonPayload, String webhookUrl) {
            HttpURLConnection conn = null;
            try {
                String targetUrl = (webhookUrl != null && !webhookUrl.trim().isEmpty()) 
                        ? webhookUrl.trim() 
                        : getWebhookUrl();

                URL url = new URL(targetUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(20000);
                conn.setDoOutput(true);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setRequestProperty("Accept", "application/json");

                byte[] postData = jsonPayload.getBytes(StandardCharsets.UTF_8);
                conn.setRequestProperty("Content-Length", String.valueOf(postData.length));

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData);
                    os.flush();
                }

                int code = conn.getResponseCode();
                InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();
            } catch (Exception e) {
                return "{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}";
            } finally {
                if (conn != null) conn.disconnect();
            }
        }

        @JavascriptInterface
        public void vibrate(int durationMs) {
            try {
                if (vibrator != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(durationMs, 255));
                    } else {
                        vibrator.vibrate(durationMs);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @JavascriptInterface
        public boolean setFlashlight(boolean state) {
            try {
                if (cameraManager != null && cameraIdWithFlash != null) {
                    cameraManager.setTorchMode(cameraIdWithFlash, state);
                    return true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }

        @JavascriptInterface
        public void playBeep(int freqHz, int durationMs) {
            try {
                ToneGenerator toneGen = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, durationMs);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @JavascriptInterface
        public boolean printRawBt(String rawData) {
            if (rawData == null || rawData.isEmpty()) return false;
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("rawbt:" + Uri.encode(rawData)));
                intent.setPackage("ru.a402d.rawbtprinter");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            } catch (Exception e) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("rawbt:" + Uri.encode(rawData)));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    return true;
                } catch (Exception ex) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Aplikasi RawBT belum terpasang", Toast.LENGTH_SHORT).show());
                    return false;
                }
            }
        }

        @JavascriptInterface
        public void requestAppPermissions() {
            runOnUiThread(() -> checkAndRequestAllPermissions());
        }
    }
}
