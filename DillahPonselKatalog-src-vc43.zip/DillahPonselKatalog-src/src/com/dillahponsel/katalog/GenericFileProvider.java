package com.dillahponsel.katalog;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

public class GenericFileProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        String path = uri.getPath();
        if (path == null) throw new FileNotFoundException("URI path is null");

        // Allow direct absolute path or cache relative path
        File file = new File(path);
        if (!file.exists()) {
            File cacheFile = new File(getContext().getCacheDir(), file.getName());
            if (cacheFile.exists()) {
                file = cacheFile;
            } else {
                File extCache = new File(getContext().getExternalCacheDir(), file.getName());
                if (extCache.exists()) {
                    file = extCache;
                }
            }
        }

        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + path);
        }

        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        return "application/vnd.android.package-archive";
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        if (projection == null) {
            projection = new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        }
        MatrixCursor cursor = new MatrixCursor(projection, 1);
        String path = uri.getPath();
        File file = (path != null) ? new File(path) : null;
        String name = (file != null) ? file.getName() : "update.apk";
        long size = (file != null && file.exists()) ? file.length() : 0;

        MatrixCursor.RowBuilder row = cursor.newRow();
        for (String col : projection) {
            if (OpenableColumns.DISPLAY_NAME.equals(col)) {
                row.add(name);
            } else if (OpenableColumns.SIZE.equals(col)) {
                row.add(size);
            } else {
                row.add(null);
            }
        }
        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
