// Data Berita Gadget Offline (GSMArena RSS Sync)
const NEWS_DATA = [
  {
    "title": "Here's your first look at Huawei's wide-screen phone from sub-brand Osta",
    "link": "https://www.gsmarena.com/heres_your_first_look_at_huaweis_widescreen_phone_from_subbrand_osta-news-75404.php",
    "date": "Mon, 09 Nov 2026",
    "desc": "According to recent rumors, Huawei is preparing to introduce a new sub-brand called Xingmang, or Osta in English. The brand's first smartpho..."
  },
  {
    "title": "One UI 9.5 to make Bixby even smarter, capable of handling daily tasks",
    "link": "https://www.gsmarena.com/one_ui_95_to_make_bixby_even_smarter_capable_of_handling_daily_tasks-news-75407.php",
    "date": "Mon, 09 Nov 2026",
    "desc": "While One UI 10 is rumored to bring major UI and usability changes, the One UI 9.5 update shapes up to be a pretty major stepping stone itse..."
  },
  {
    "title": "It's official: the Xiaomi 18 Pro and 18 Pro Max are launching globally next week",
    "link": "https://www.gsmarena.com/its_official_the_xiaomi_18_pro_and_18_pro_max_are_launching_globally_next_week-news-75406.php",
    "date": "Mon, 09 Nov 2026",
    "desc": "The Xiaomi 18 Pro series launched in China in late September. Since then, the company has dialed in the time frame for the global launch – i..."
  },
  {
    "title": "The Oppo Pad Air6 (aka Oppo Pad 6) unveiled, sales start next week",
    "link": "https://www.gsmarena.com/the_oppo_pad_air6_aka_oppo_pad_6_gets_unveiled_today_will_launch_next_week-news-75405.php",
    "date": "Mon, 09 Nov 2026",
    "desc": "The Oppo Reno17 series is coming next week and instead of waiting until then, the company decided to reveal the new Oppo Pad Air6 today and ..."
  },
  {
    "title": "Here's what vivo will probably call its first gimbal camera",
    "link": "https://www.gsmarena.com/heres_what_vivo_will_probably_call_its_first_gimbal_camera-news-75402.php",
    "date": "Mon, 09 Nov 2026",
    "desc": "We've long heard that both Oppo and vivo are working on their very own gimbal cameras meant to compete with DJI's Osmo Pocket line and Insta..."
  },
  {
    "title": "Honor 700 devices teased to come with an interesting feature on the rear screen",
    "link": "https://www.gsmarena.com/honor_700_devices_teased_to_come_with_an_interesting_feature_on_the_rear_screen-news-75401.php",
    "date": "Mon, 09 Nov 2026",
    "desc": "A few days ago, Honor officially revealed the design of the upcoming 700, 700 Pro, and 700S. All three phones will have a rear display insid..."
  }
];
