/* ============================================================
   Katalog Produk — Dillah Ponsel & Komputer
   Edit file ini untuk mengubah isi katalog.
   ============================================================ */

window.PRODUK = [
  // ─── iPHONE PRE-ORDER (RESMI iBOX) ────────────────────────
  {
    id: "iphone-18-promax",
    nama: "iPhone 18 Pro Max 256GB (Pre-Order)",
    kategori: "hp",
    kondisi: "Pre Order",
    harga: 29499000,
    garansi: "Garansi resmi 1 tahun iBox",
    stok: 0,
    gambar: "assets/produk_img/iphone-18-pro-max.jpg",
    catatan: [
      "⚠️ STATUS: PRE-ORDER (PO) RESMI iBOX INDONESIA",
      "Barang tidak selalu ready di toko, wajib booking DP / tanda jadi",
      "Harga resmi iBox: 256GB Rp 29.499.000 | 512GB Rp 34.999.000 | 1TB Rp 44.999.000",
      "Warna: Desert Titanium, Natural Titanium, White Titanium, Black Titanium",
      "Estimasi unit tiba: 2 - 4 hari kerja setelah pemesanan"
    ]
  },
  {
    id: "iphone-18-pro",
    nama: "iPhone 18 Pro 256GB (Pre-Order)",
    kategori: "hp",
    kondisi: "Pre Order",
    harga: 27499000,
    garansi: "Garansi resmi 1 tahun iBox",
    stok: 0,
    gambar: "assets/produk_img/iphone-18-pro.jpg",
    catatan: [
      "⚠️ STATUS: PRE-ORDER (PO) RESMI iBOX INDONESIA",
      "Barang tidak selalu ready di toko, wajib booking DP / tanda jadi",
      "Harga resmi iBox: 256GB Rp 27.499.000 | 512GB Rp 32.999.000 | 1TB Rp 41.999.000",
      "Chipset Apple A20 Pro super kencang, layar ProMotion 120Hz",
      "Estimasi unit tiba: 2 - 4 hari kerja setelah pemesanan"
    ]
  },

  // ─── STOK iPHONE BARU (RESMI INDONESIA) ───────────────────
  {
    id: "iphone-17-promax-silver",
    nama: "iPhone 17 Pro Max 256GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 25000000,
    garansi: "Garansi resmi 1 tahun iBox",
    stok: 1,
    gambar: "assets/produk_img/iphone-17-pro-max.jpg",
    catatan: ["Warna: Silver", "Internal 256GB", "Garansi resmi Indonesia (iBox/Erajaya)", "Brand new in box (BNIB) segel green peel"]
  },
  {
    id: "iphone-17-pro-silver",
    nama: "iPhone 17 Pro 256GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 23000000,
    garansi: "Garansi resmi 1 tahun iBox",
    stok: 2,
    gambar: "assets/produk_img/iphone-17-pro.jpg",
    catatan: ["Warna: Silver", "Internal 256GB", "Garansi resmi Indonesia (iBox)", "Segel resmi BNIB"]
  },
  {
    id: "iphone-16-pink",
    nama: "iPhone 16 128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 15500000,
    garansi: "Garansi resmi 1 tahun iBox",
    stok: 1,
    gambar: "assets/produk_img/iphone-16-pink.jpg",
    catatan: ["Warna: Pink", "Internal 128GB", "Garansi resmi iBox Indonesia", "Brand New Segel"]
  },
  {
    id: "iphone-15-black",
    nama: "iPhone 15 128GB Black",
    kategori: "hp",
    kondisi: "Baru",
    harga: 13000000,
    garansi: "Garansi resmi 1 tahun iBox",
    stok: 1,
    gambar: "assets/produk_img/iphone-15-black.jpg",
    catatan: ["Warna: Black", "Internal 128GB", "Dynamic Island, Type-C", "Garansi resmi iBox Indonesia"]
  },
  {
    id: "iphone-15-pink",
    nama: "iPhone 15 128GB Pink",
    kategori: "hp",
    kondisi: "Baru",
    harga: 13000000,
    garansi: "Garansi resmi 1 tahun iBox",
    stok: 0,
    gambar: "assets/produk_img/iphone-15-pink.jpg",
    catatan: ["Warna: Pink", "Internal 128GB", "Dynamic Island, Type-C", "Garansi resmi iBox Indonesia"]
  },

  // ─── STOK ANDROID BARU ────────────────────────────────────
  {
    id: "samsung-a57",
    nama: "Samsung Galaxy A57 5G 12/256GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 9000000,
    garansi: "Garansi resmi 1 tahun",
    stok: 1,
    gambar: "assets/produk_img/samsung-a57.jpg",
    catatan: ["Warna: Awesome Gray", "RAM 12GB / Internal 256GB", "Layar 120Hz Super AMOLED", "5G ready, segel resmi"]
  },
  {
    id: "samsung-a37",
    nama: "Samsung Galaxy A37 5G 8/256GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 7000000,
    garansi: "Garansi resmi 1 tahun",
    stok: 1,
    gambar: "assets/produk_img/samsung-a37.jpg",
    catatan: ["Warna: Awesome Lavender", "RAM 8GB / Internal 256GB", "Garansi resmi SEIN 1 tahun"]
  },
  {
    id: "samsung-a07",
    nama: "Samsung Galaxy A07 4/64GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2300000,
    garansi: "Garansi resmi 1 tahun",
    stok: 17,
    gambar: "assets/produk_img/samsung-a07.jpg",
    catatan: ["Pilihan warna: Black (6), Green (5), Light Violet (6)", "Baterai 5000mAh", "Garansi resmi"]
  },
  {
    id: "samsung-a08",
    nama: "Samsung Galaxy A08 4/64GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 3000000,
    garansi: "Garansi resmi 1 tahun",
    stok: 2,
    gambar: "assets/produk_img/samsung-a08.jpg",
    catatan: ["Pilihan warna: Green, Dark Blue", "RAM 4GB / Internal 64GB", "Segel resmi"]
  },
  {
    id: "oppo-a6x",
    nama: "Oppo A6x 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2899000,
    garansi: "Garansi resmi 1 tahun",
    stok: 1,
    gambar: "assets/produk_img/oppo-a6x.jpg",
    catatan: ["Warna: Ungu Tua", "RAM 4GB / Internal 128GB", "Garansi resmi Oppo Indonesia"]
  },
  {
    id: "oppo-a6c-64",
    nama: "Oppo A6c 4/64GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2699000,
    garansi: "Garansi resmi 1 tahun",
    stok: 2,
    gambar: "assets/produk_img/oppo-a6c-64.jpg",
    catatan: ["Pilihan warna: Ungu, Coklat", "Desain ramping tahan cipratan air", "Garansi resmi"]
  },
  {
    id: "oppo-a6c-128",
    nama: "Oppo A6c 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 3099000,
    garansi: "Garansi resmi 1 tahun",
    stok: 0,
    gambar: "assets/produk_img/oppo-a6c-128.jpg",
    catatan: ["Warna: Putih", "RAM 4GB / Internal 128GB lega", "Garansi resmi"]
  },
  {
    id: "vivo-y05",
    nama: "Vivo Y05 4/64GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2649000,
    garansi: "Garansi resmi 1 tahun",
    stok: 3,
    gambar: "assets/produk_img/vivo-y05.jpg",
    catatan: ["Pilihan warna: Black, Blue", "Garansi resmi Vivo"]
  },
  {
    id: "realme-note80-128",
    nama: "Realme Note 80 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2399000,
    garansi: "Garansi resmi 1 tahun",
    stok: 0,
    gambar: "assets/produk_img/realme-note80-128.jpg",
    catatan: ["Warna: Storm Black", "ArmorShell Protection tahan banting", "Garansi resmi"]
  },
  {
    id: "realme-note80-64",
    nama: "Realme Note 80 4/64GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2099000,
    garansi: "Garansi resmi 1 tahun",
    stok: 4,
    gambar: "assets/produk_img/realme-note80-64.jpg",
    catatan: ["Pilihan warna: Storm Black (2), Glacier Blue (2)", "Bodi tahan percikan IP54", "Garansi resmi"]
  },
  {
    id: "realme-p4x",
    nama: "Realme P4x 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2500000,
    garansi: "Garansi resmi 1 tahun",
    stok: 1,
    gambar: "assets/produk_img/realme-p4x.jpg",
    catatan: ["Warna: Rally White", "Layar 90Hz Comfort Display", "Garansi resmi"]
  },
  {
    id: "redmi-a7pro",
    nama: "Redmi A7 Pro 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2200000,
    garansi: "Garansi resmi 1 tahun",
    stok: 13,
    gambar: "assets/produk_img/redmi-a7pro.jpg",
    catatan: ["Pilihan warna: Sunset Orange (5), Black (4), Mist Blue (2), Palm Green (2)", "Layar besar 6.88 inci 120Hz", "Garansi resmi Xiaomi"]
  },
  {
    id: "poco-x8pro",
    nama: "Poco X8 Pro 12/512GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 7000000,
    garansi: "Garansi resmi 1 tahun",
    stok: 7,
    gambar: "assets/produk_img/poco-x8pro.jpg",
    catatan: ["Pilihan warna: Mint Green, White (3), Black (3)", "RAM Monster 12GB + Storage 512GB", "Performa gaming kencang, garansi resmi"]
  },
  {
    id: "poco-c71",
    nama: "Poco C71 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2100000,
    garansi: "Garansi resmi 1 tahun",
    stok: 1,
    gambar: "assets/produk_img/poco-c71.jpg",
    catatan: ["Warna: Black", "RAM 4GB / Internal 128GB", "Baterai awet 5000mAh", "Garansi resmi"]
  },
  {
    id: "infinix-note60",
    nama: "Infinix Note 60 8/256GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 5000000,
    garansi: "Garansi resmi 1 tahun",
    stok: 0,
    gambar: "assets/produk_img/infinix-note60.jpg",
    catatan: ["Warna: Midnight Black", "RAM 8GB / 256GB", "All-Round FastCharge", "Garansi resmi"]
  },
  {
    id: "infinix-smart20-128",
    nama: "Infinix Smart 20 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2400000,
    garansi: "Garansi resmi 1 tahun",
    stok: 10,
    gambar: "assets/produk_img/infinix-smart20-128.jpg",
    catatan: ["Pilihan warna: Shadow Black (5), Polaris Titanium (5)", "Internal besar 128GB", "Garansi resmi"]
  },
  {
    id: "infinix-smart20-64",
    nama: "Infinix Smart 20 4/64GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2100000,
    garansi: "Garansi resmi 1 tahun",
    stok: 10,
    gambar: "assets/produk_img/infinix-smart20-64.jpg",
    catatan: ["Pilihan warna: Sunlike Orange (2), Polaris Titanium (2), Shadow Black (3), Cloudline Blue (3)", "Speaker stereo kencang", "Garansi resmi"]
  },
  {
    id: "infinix-hot70-256",
    nama: "Infinix Hot 70 6/256GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 3600000,
    garansi: "Garansi resmi 1 tahun",
    stok: 1,
    gambar: "assets/produk_img/infinix-hot70-256.jpg",
    catatan: ["Warna: Night Pulse", "RAM 6GB / Internal 256GB lega", "Garansi resmi"]
  },
  {
    id: "infinix-hot70-128",
    nama: "Infinix Hot 70 8/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 3400000,
    garansi: "Garansi resmi 1 tahun",
    stok: 1,
    gambar: "assets/produk_img/infinix-hot70-128.jpg",
    catatan: ["Warna: Night Pulse", "RAM 8GB kencang", "Garansi resmi"]
  },
  {
    id: "infinix-hot70-4-128",
    nama: "Infinix Hot 70 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2800000,
    garansi: "Garansi resmi 1 tahun",
    stok: 1,
    gambar: "assets/produk_img/infinix-hot70-4-128.jpg",
    catatan: ["Warna: Night Pulse", "RAM 4GB / Internal 128GB", "Garansi resmi"]
  },
  {
    id: "tecno-spark-go3-64",
    nama: "Tecno Spark Go 3 4/64GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 1999000,
    garansi: "Garansi resmi 1 tahun",
    stok: 3,
    gambar: "assets/produk_img/tecno-spark-go3-64.jpg",
    catatan: ["Pilihan warna: Aurora Purple (2), Flare White (1)", "Layar 120Hz smooth", "Garansi resmi"]
  },
  {
    id: "tecno-spark-go3-128",
    nama: "Tecno Spark Go 3 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2199000,
    garansi: "Garansi resmi 1 tahun",
    stok: 3,
    gambar: "assets/produk_img/tecno-spark-go3-128.jpg",
    catatan: ["Pilihan warna: Ink Black (2), Aurora Purple (1)", "Internal 128GB", "Garansi resmi"]
  },
  {
    id: "tecno-spark50-6-128",
    nama: "Tecno Spark 50 6/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2999000,
    garansi: "Garansi resmi 1 tahun",
    stok: 2,
    gambar: "assets/produk_img/tecno-spark50-6-128.jpg",
    catatan: ["Pilihan warna: Dynamic Orange, Neo Titanium", "RAM 6GB kencang", "Kamera jernih, garansi resmi"]
  },
  {
    id: "tecno-spark50-4-128",
    nama: "Tecno Spark 50 4/128GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 2599000,
    garansi: "Garansi resmi 1 tahun",
    stok: 3,
    gambar: "assets/produk_img/tecno-spark50-4-128.jpg",
    catatan: ["Pilihan warna: Bloom Pink (2), Ink Black (1)", "Garansi resmi"]
  },
  {
    id: "iqoo-15r",
    nama: "iQOO 15R 8/256GB 5G",
    kategori: "hp",
    kondisi: "Baru",
    harga: 8500000,
    garansi: "Garansi resmi 1 tahun",
    stok: 2,
    gambar: "assets/produk_img/iqoo-15r.jpg",
    catatan: ["Pilihan warna: Silver, Black", "RAM 8GB / 256GB", "Flagship gaming monster", "Garansi resmi"]
  },
  {
    id: "inoi-8-512",
    nama: "Inoi 8/512GB",
    kategori: "hp",
    kondisi: "Baru",
    harga: 3000000,
    garansi: "Garansi resmi 1 tahun",
    stok: 8,
    gambar: "assets/produk_img/inoi-8-512.jpg",
    catatan: ["Warna: Hitam", "Kapasitas raksasa: RAM 8GB + Internal 512GB", "Baterai awet, garansi resmi"]
  }
];

/* Info toko */
window.TOKO = {
  nama: "Dillah Ponsel & Komputer",
  tagline: "HP, laptop, dan aksesoris — baru & bekas, bergaransi.",
  alamat: "Mabuun, Murung Pudak, Tabalong, Kalimantan Selatan",
  jam: "Setiap hari 08.00 – 21.00 WITA",
  wa: "6285248642264",
  wa2: "6282323889445",
  ig: "https://instagram.com/dillah.ponsel",
  tiktok: "https://www.tiktok.com/@dillahponsel.tanjung",
  fb: "https://facebook.com/dillah.kaixa",
  threads: "https://www.threads.net/@dillah.ponsel",
  waChannel: "https://whatsapp.com/channel/0029Vb88T75GJP8MmRp5ZH2W",
  maps: "https://www.google.com/maps/search/?api=1&query=Mabuun+Murung+Pudak+Tabalong"
};
