/* ============================================================
   Data Stok HP Second (Bekas Berkualitas) — Dillah Ponsel
   Format: List terstruktur dengan harga tersensor 3 digit
   untuk memicu calon pembeli langsung bertanya via WhatsApp.
   ============================================================ */

window.HP_SEKEN = [
  // ─── iPHONE SEKEN (RESMI) ────────────────────────────────
  {
    id: "sek-ip16plus-pink",
    gambar: "assets/produk_img/iphone-16-pink.jpg",
    brand: "Apple",
    nama: "iPhone 16 Plus 128GB",
    warna: "Pink",
    kondisi: "Bekas Mulus (No Minus)",
    kelengkapan: "Battery Health 100% · Fullset · Garansi Resmi TAM",
    hargaTampil: "Rp 14.xxx.000",
    hargaAsli: 14500000
  },
    {
    id: "sek-ip17pm-orange",
    gambar: "assets/produk_img/iphone-17-pro-max.jpg",
    brand: "Apple",
    nama: "iPhone 17 Pro Max 256GB",
    warna: "Orange",
    kondisi: "Pemakaian 10 Hari (Like New)",
    kelengkapan: "Battery Health 100% · Original · Garansi Resmi",
    hargaTampil: "Rp 23.xxx.000",
    hargaAsli: 23500000
  },
  {
    id: "sek-ip17pm-deepblue",
    gambar: "assets/produk_img/iphone-17-pro-max.jpg",
    brand: "Apple",
    nama: "iPhone 17 Pro Max 256GB",
    warna: "Deep Blue",
    kondisi: "Bekas Mulus (Like New)",
    kelengkapan: "Battery Health 100% · Original · Garansi Resmi",
    hargaTampil: "Rp 23.xxx.000",
    hargaAsli: 23500000
  },
  {
    id: "sek-ip17p-deepblue",
    gambar: "assets/produk_img/iphone-17-pro.jpg",
    brand: "Apple",
    nama: "iPhone 17 Pro 256GB",
    warna: "Deep Blue",
    kondisi: "Bekas Mulus",
    kelengkapan: "Battery Health 93% · Original · Garansi Resmi",
    hargaTampil: "Rp 19.xxx.000",
    hargaAsli: 19500000
  },
  {
    id: "sek-ip17-lavender",
    gambar: "assets/produk_img/iphone-17.jpg",
    brand: "Apple",
    nama: "iPhone 17 256GB",
    warna: "Lavender",
    kondisi: "Bekas Like New",
    kelengkapan: "Battery Health 100% · Original · Garansi Resmi",
    hargaTampil: "Rp 16.xxx.000",
    hargaAsli: 16900000
  },
  {
    id: "sek-ip15pm-black",
    gambar: "assets/produk_img/iphone-15-black.jpg",
    brand: "Apple",
    nama: "iPhone 15 Pro Max 256GB",
    warna: "Black Titanium",
    kondisi: "Bekas Mulus",
    kelengkapan: "Battery Health 88% · Original · Garansi Resmi",
    hargaTampil: "Rp 15.xxx.000",
    hargaAsli: 15800000
  },
  {
    id: "sek-ip15p-natural",
    gambar: "assets/produk_img/iphone-15-black.jpg",
    brand: "Apple",
    nama: "iPhone 15 Pro 256GB",
    warna: "Natural Titanium",
    kondisi: "Bekas Mulus",
    kelengkapan: "Battery Health 83% · Original · Garansi Resmi",
    hargaTampil: "Rp 15.xxx.000",
    hargaAsli: 15000000
  },
  {
    id: "sek-ip13-512-midnight",
    gambar: "assets/produk_img/iphone-13.jpg",
    brand: "Apple",
    nama: "iPhone 13 512GB",
    warna: "Midnight",
    kondisi: "Bekas Mulus",
    kelengkapan: "Battery Health 86% · Original · Garansi Resmi",
    hargaTampil: "Rp 10.xxx.000",
    hargaAsli: 10000000
  },
  {
    id: "sek-ip13-256-blue",
    gambar: "assets/produk_img/iphone-13.jpg",
    brand: "Apple",
    nama: "iPhone 13 256GB",
    warna: "Blue",
    kondisi: "Bekas Mulus",
    kelengkapan: "Battery Health 83% · Original · Garansi Resmi",
    hargaTampil: "Rp 9.xxx.000",
    hargaAsli: 9000000
  },
  {
    id: "sek-ip12p-128-graphite",
    gambar: "assets/produk_img/iphone-12-pro.jpg",
    brand: "Apple",
    nama: "iPhone 12 Pro 128GB",
    warna: "Graphite",
    kondisi: "Bekas Normal",
    kelengkapan: "Battery Health 73% · Original · Garansi Resmi",
    hargaTampil: "Rp 6.xxx.000",
    hargaAsli: 6900000
  },
  {
    id: "sek-ip12-128-black",
    gambar: "assets/produk_img/iphone-12.jpg",
    brand: "Apple",
    nama: "iPhone 12 128GB",
    warna: "Black",
    kondisi: "Bekas Normal",
    kelengkapan: "Battery Health 78% · Original · Garansi Resmi",
    hargaTampil: "Rp 5.xxx.000",
    hargaAsli: 5500000
  },
  {
    id: "sek-ip11-64-black",
    gambar: "assets/produk_img/iphone-11.jpg",
    brand: "Apple",
    nama: "iPhone 11 64GB",
    warna: "Black",
    kondisi: "Bekas Normal",
    kelengkapan: "Battery Health 71% · Original · Garansi Resmi",
    hargaTampil: "Rp 4.xxx.000",
    hargaAsli: 4000000
  },

  // ─── ANDROID SEKEN (TERVERIFIKASI AKTIF) ──────────────────
  {
    id: "sek-samsung-s25fe",
    gambar: "assets/produk_img/samsung-a57.jpg",
    brand: "Samsung",
    nama: "Samsung Galaxy S25 FE 8/256GB",
    warna: "Jetblack",
    kondisi: "Bekas Mulus",
    kelengkapan: "Fullset, fungsi normal 100%",
    hargaTampil: "Rp 8.xxx.000",
    hargaAsli: 8250000
  },
  {
    id: "sek-samsung-s25edge",
    gambar: "assets/produk_img/samsung-a57.jpg",
    brand: "Samsung",
    nama: "Samsung Galaxy S25 edge 12/512GB",
    warna: "Black",
    kondisi: "Bekas Mulus",
    kelengkapan: "Unit + charger, performa prima",
    hargaTampil: "Rp 12.xxx.000",
    hargaAsli: 12500000
  },
  {
    id: "sek-samsung-zflip5",
    gambar: "assets/produk_img/samsung-zflip5.jpg",
    brand: "Samsung",
    nama: "Samsung Galaxy Z Flip5 8/512GB",
    warna: "Standar",
    kondisi: "Bekas Mulus",
    kelengkapan: "Engsel normal, layar jernih",
    hargaTampil: "Rp 5.xxx.000",
    hargaAsli: 5300000
  },
  {
    id: "sek-samsung-a37",
    gambar: "assets/produk_img/samsung-a37.jpg",
    brand: "Samsung",
    nama: "Samsung Galaxy A37 5G 8/128GB",
    warna: "Awesome Graygreen",
    kondisi: "Bekas Mulus",
    kelengkapan: "Fullset, garansi toko",
    hargaTampil: "Rp 6.xxx.000",
    hargaAsli: 6400000
  },
  {
    id: "sek-samsung-a27",
    gambar: "assets/produk_img/samsung-a07.jpg",
    brand: "Samsung",
    nama: "Samsung Galaxy A27 8/256GB",
    warna: "Black",
    kondisi: "Bekas Mulus",
    kelengkapan: "Fullset normal, baterai awet",
    hargaTampil: "Rp 4.xxx.000",
    hargaAsli: 4750000
  },
  {
    id: "sek-samsung-s24fe",
    gambar: "assets/produk_img/samsung-s24fe.jpg",
    brand: "Samsung",
    nama: "Samsung Galaxy S24 FE 8/128GB",
    warna: "Blue",
    kondisi: "Bekas Mulus",
    kelengkapan: "Fullset normal, mulus terawat",
    hargaTampil: "Rp 5.xxx.000",
    hargaAsli: 5800000
  },
  {
    id: "sek-iqoo-15r",
    gambar: "assets/produk_img/iqoo-15r.jpg",
    brand: "Vivo",
    nama: "IQOO 15R 12/256GB",
    warna: "Silver",
    kondisi: "Bekas Like New",
    kelengkapan: "Fullset, performa kencang flagship",
    hargaTampil: "Rp 8.xxx.000",
    hargaAsli: 8800000
  },
  {
    id: "sek-vivo-y05e",
    gambar: "assets/produk_img/vivo-y05.jpg",
    brand: "Vivo",
    nama: "Vivo Y05e 4/64GB",
    warna: "Black",
    kondisi: "Bekas Normal",
    kelengkapan: "Fisik terawat, siap pakai",
    hargaTampil: "Rp 1.xxx.000",
    hargaAsli: 1800000
  },
  {
    id: "sek-oppo-a6s-128",
    gambar: "assets/produk_img/oppo-a6c-128.jpg",
    brand: "Oppo",
    nama: "Oppo A6s 8/128GB",
    warna: "Cokelat",
    kondisi: "Buka Kotak (BNOB)",
    kelengkapan: "Like new baru buka segel",
    hargaTampil: "Rp 4.xxx.000",
    hargaAsli: 4000000
  },
  {
    id: "sek-oppo-a6s-64",
    gambar: "assets/produk_img/oppo-a6c-64.jpg",
    brand: "Oppo",
    nama: "Oppo A6s 4/64GB",
    warna: "Coklat",
    kondisi: "Pemakaian Seminggu",
    kelengkapan: "Istimewa mulus tanpa lecet",
    hargaTampil: "Rp 2.xxx.000",
    hargaAsli: 2300000
  },
  {
    id: "sek-oppo-a6x",
    gambar: "assets/produk_img/oppo-a6x.jpg",
    brand: "Oppo",
    nama: "OPPO A6x 4/64GB",
    warna: "Ungu Muda",
    kondisi: "Bekas Normal",
    kelengkapan: "Unit normal, bergaransi",
    hargaTampil: "Rp 2.xxx.000",
    hargaAsli: 2100000
  },
  {
    id: "sek-oppo-a6c",
    gambar: "assets/produk_img/oppo-a6c-64.jpg",
    brand: "Oppo",
    nama: "Oppo A6c 4/64GB",
    warna: "Coklat",
    kondisi: "Bekas Normal",
    kelengkapan: "Siap pakai, baterai sehat",
    hargaTampil: "Rp 2.xxx.000",
    hargaAsli: 2400000
  },
  {
    id: "sek-huawei-pura70ultra",
    gambar: "assets/produk_img/huawei-pura70ultra.jpg",
    brand: "Huawei",
    nama: "Huawei Pura 70 Ultra 16/512GB",
    warna: "Black",
    kondisi: "Bekas Like New",
    kelengkapan: "Flagship kamera terbaik, fullset",
    hargaTampil: "Rp 10.xxx.000",
    hargaAsli: 10000000
  },
  {
    id: "sek-infinix-note60pro",
    gambar: "assets/produk_img/infinix-note60.jpg",
    brand: "Infinix",
    nama: "Infinix Note 60 Pro 8/256GB",
    warna: "Deep Ocean Blue",
    kondisi: "Bekas Mulus",
    kelengkapan: "Performa kencang, layar mulus",
    hargaTampil: "Rp 4.xxx.000",
    hargaAsli: 4800000
  },
  {
    id: "sek-infinix-smart20",
    gambar: "assets/produk_img/infinix-smart20-128.jpg",
    brand: "Infinix",
    nama: "Infinix SMART 20 4/128GB",
    warna: "Cloudline Blue",
    kondisi: "Bekas Normal",
    kelengkapan: "Baterai awet, fungsi normal",
    hargaTampil: "Rp 1.xxx.000",
    hargaAsli: 1900000
  }
];
