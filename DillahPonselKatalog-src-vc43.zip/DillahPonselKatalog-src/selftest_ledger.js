#!/usr/bin/env node
/**
 * Self-test headless untuk fitur Buku Taksiran Kasir + grafik tren (uPlot).
 * Menjalankan assets/index.html di Chrome headless via CDP, mengisi form tukar
 * tambah seperti kasir sungguhan, lalu memverifikasi:
 *  1. lib uPlot & modul DillahLedger termuat
 *  2. kalkulasi mengisi form -> entri tercatat di localStorage (upsert per voucher)
 *  3. mengubah kondisi tidak menumpuk entri (masih 1 entri untuk voucher sama)
 *  4. grafik benar-benar tergambar (canvas uPlot ada & ada piksel tinta)
 *  5. kartu statistik & daftar taksiran terakhir ter-render
 *  6. ganti tipe HP lama -> voucher baru, entri jadi 2
 *  7. ekspor CSV berisi header & baris data
 *  8. hapus semua -> state bersih, grafik disembunyikan
 *  9. 0 JS error
 */
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");

const DIR = path.resolve(__dirname);
const PORT = 9800 + Math.floor(Math.random() * 400);
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const PAGE = "file://" + path.join(DIR, "assets", "index.html");

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function cdp(ws, method, params) {
  return new Promise((resolve, reject) => {
    const id = ++ws._id;
    const off = ws.onMessage((m) => {
      if (m.id === id) {
        off();
        m.error ? reject(new Error(method + ": " + JSON.stringify(m.error))) : resolve(m.result);
      }
    });
    ws.send({ id, method, params: params || {} });
    setTimeout(() => { off(); reject(new Error("timeout " + method)); }, 30000);
  });
}

async function evalJS(ws, expr) {
  const res = await cdp(ws, "Runtime.evaluate", {
    expression: expr,
    awaitPromise: true,
    returnByValue: true
  });
  if (res.exceptionDetails) {
    throw new Error("JS exception: " + JSON.stringify(res.exceptionDetails.exception || res.exceptionDetails.text));
  }
  return res.result.value;
}

(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), "ledgertest_"));
  const chrome = spawn(CHROME, [
    "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
    "--remote-debugging-port=" + PORT, "--user-data-dir=" + profile,
    "--allow-file-access-from-files", "--window-size=412,915", PAGE
  ], { stdio: "ignore" });

  const results = {};
  let ws;
  try {
    let pageTarget = null;
    for (let i = 0; i < 60; i++) {
      try {
        const r = await fetch(`http://127.0.0.1:${PORT}/json/list`);
        const targets = await r.json();
        pageTarget = targets.find(t => t.type === "page" && t.url === PAGE && t.webSocketDebuggerUrl);
        if (pageTarget) break;
      } catch (e) {}
      await sleep(300);
    }
    if (!pageTarget) throw new Error("Target halaman tidak ditemukan di port " + PORT);
    const { connectWS } = require("./wshelper.js");
    ws = await connectWS(pageTarget.webSocketDebuggerUrl);
    ws._id = 0;

    await cdp(ws, "Runtime.enable");
    await cdp(ws, "Page.enable");
    await sleep(1200);
    await cdp(ws, "Page.reload", { ignoreCache: true });
    await sleep(2600);

    // Pasang penangkap error setelah reload
    await evalJS(ws, `(() => {
      window.__jsErrors = [];
      window.addEventListener("error", e => window.__jsErrors.push(String(e.message)));
      window.addEventListener("unhandledrejection", e => window.__jsErrors.push("rejection: " + String(e.reason)));
      return true;
    })()`);

    let ready = false;
    for (let i = 0; i < 60; i++) {
      const probe = await evalJS(ws, `(function(){ try { return document.readyState === "complete" &&
        typeof window.uPlot === "function" &&
        typeof window.DillahLedger === "object" &&
        typeof window.renderLedger === "function" &&
        typeof state === "object"; } catch(e) { return false; } })()`).catch(() => false);
      if (probe === true) { ready = true; break; }
      await sleep(300);
    }
    results.appReady = ready;
    if (!ready) throw new Error("App tidak siap setelah 18s");

    // 1. Modul termuat
    results.uplotLoaded = await evalJS(ws, "typeof window.uPlot === 'function'");
    results.ledgerLoaded = await evalJS(ws, "typeof window.DillahLedger === 'object' && typeof DillahLedger.upsert === 'function'");

    // Bersihkan state lama supaya tes deterministik
    await evalJS(ws, "DillahLedger.clear(); state.currentTradeInVoucher = null; state.produk.length && calculateTradeIn(); true");

    // 2. Isi form seperti kasir: HP incaran + HP lama + pasaran
    results.fillForm = await evalJS(ws, `(() => {
      const selPersetujuan = document.getElementById("calcUnitTujuan");
      if (selPersetujuan && selPersetujuan.options.length > 1) selPersetujuan.selectedIndex = 1;
      document.getElementById("calcHpLamaNama").value = "iPhone 11 128GB";
      document.getElementById("calcHpLamaPasar").value = "4200000";
      document.getElementById("calcGaransiSinyal").value = "resmi";
      document.getElementById("calcKondisiFisik").value = "grade_a";
      document.getElementById("calcBatteryHealth").value = "bh_normal";
      document.getElementById("calcKelengkapan").value = "fullset";
      calculateTradeIn();
      return {
        pasaran: document.getElementById("resPasarLama").innerText,
        taksiran: document.getElementById("resTaksirLama").innerText,
        sisa: document.getElementById("resSisaBayar").innerText,
        voucher: state.currentTradeInVoucher
      };
    })()`);

    // Tunggu debounce 550ms + render
    await sleep(1100);

    results.firstEntry = await evalJS(ws, `(() => {
      const all = DillahLedger.all();
      return {
        count: all.length,
        rec: all[0] || null,
        storedInLs: !!localStorage.getItem(DillahLedger.STORAGE_KEY)
      };
    })()`);

    // 3. Grafik tergambar: canvas uPlot ada dan ada piksel tinta
    results.chart = await evalJS(ws, `(() => {
      const host = document.getElementById("ledgerChart");
      const cv = host ? host.querySelector("canvas") : null;
      if (!cv) return { error: "canvas uPlot tidak ada", hostHtml: host ? host.innerHTML.slice(0, 120) : null };
      const ctx = cv.getContext("2d");
      const d = ctx.getImageData(0, 0, cv.width, cv.height).data;
      let ink = 0;
      for (let i = 0; i < d.length; i += 4) {
        if (d[i + 3] > 10 && (d[i] + d[i+1] + d[i+2]) < 720) ink++;
      }
      return {
        ok: true,
        w: cv.width, h: cv.height,
        inkPx: ink,
        emptyHidden: document.getElementById("ledgerEmpty").style.display === "none",
        hostVisible: host.style.display !== "none"
      };
    })()`);

    // 4. Statistik & daftar terakhir
    results.stats = await evalJS(ws, `(() => {
      const box = document.getElementById("ledgerStats");
      return {
        cards: box ? box.children.length : 0,
        text: box ? box.innerText.replace(/\\n+/g, " | ").slice(0, 160) : "",
        subtitle: document.getElementById("ledgerSubtitle").innerText,
        recentVisible: document.getElementById("ledgerRecentWrap").style.display !== "none",
        recentRows: document.getElementById("ledgerRecentList").children.length
      };
    })()`);

    // 5. Ubah kondisi -> voucher sama, entri TIDAK menumpuk
    results.noDuplicate = await evalJS(ws, `(async () => {
      document.getElementById("calcKondisiFisik").value = "grade_c";
      calculateTradeIn();
      await new Promise(r => setTimeout(r, 900));
      const all = DillahLedger.all();
      return {
        count: all.length,
        taksiran: all[0] ? all[0].taksiran : 0,
        grade: all[0] ? all[0].grade : null
      };
    })()`);

    // 6. Ganti tipe HP lama -> voucher baru, entri jadi 2
    results.newDeal = await evalJS(ws, `(async () => {
      const before = state.currentTradeInVoucher;
      document.getElementById("calcHpLamaNama").value = "Samsung A54 256GB";
      document.getElementById("calcHpLamaPasar").value = "3100000";
      document.getElementById("calcKondisiFisik").value = "grade_a";
      calculateTradeIn();
      await new Promise(r => setTimeout(r, 900));
      const all = DillahLedger.all();
      return {
        voucherChanged: state.currentTradeInVoucher !== before,
        count: all.length,
        names: all.map(a => a.namaLama)
      };
    })()`);

    // 7. Deret waktu benar-benar terisi di hari ini
    results.series = await evalJS(ws, `(() => {
      const s = DillahLedger.series(14);
      const last = s.count.length - 1;
      return {
        points: s.count.length,
        labelsSample: [s.labels[0], s.labels[last]],
        todayCount: s.count[last],
        todayAvgJuta: s.avgTaksiran[last],
        totalCounted: s.count.reduce((a, b) => a + b, 0)
      };
    })()`);

    // 8. Ekspor CSV
    results.csv = await evalJS(ws, `(() => {
      const csv = DillahLedger.toCsv();
      const lines = csv.split("\\n");
      return {
        hasHeader: lines[0].startsWith("Kode;Waktu"),
        rows: lines.length - 1,
        sample: lines[1] ? lines[1].slice(0, 90) : null
      };
    })()`);

    // 9. Rentang 7H / 30H tidak error
    results.ranges = await evalJS(ws, `(async () => {
      const out = {};
      for (const d of [7, 30, 14]) {
        window.setLedgerRange(d);
        await new Promise(r => setTimeout(r, 260));
        out["d" + d] = !!document.querySelector("#ledgerChart canvas");
      }
      return out;
    })()`);

    // 10. Hapus semua
    results.afterClear = await evalJS(ws, `(async () => {
      window.confirm = () => true;
      window.clearLedger();
      await new Promise(r => setTimeout(r, 300));
      return {
        count: DillahLedger.count(),
        lsEmpty: !localStorage.getItem(DillahLedger.STORAGE_KEY),
        emptyVisible: document.getElementById("ledgerEmpty").style.display !== "none",
        statsCards: document.getElementById("ledgerStats").children.length
      };
    })()`);

    results.jsErrors = await evalJS(ws, "window.__jsErrors || []");

    // Simpan tangkapan layar kartu buku taksiran (bukti visual)
    try {
      await evalJS(ws, `(async () => {
        DillahLedger.clear();
        state.currentTradeInVoucher = null;
        const seed = [
          { kode: "DLH-TT-SEED-01", namaLama: "iPhone 11 128GB", namaTujuan: "iPhone 13 128GB", pasaran: 4200000, taksiran: 3610000, selisih: 3890000, grade: "grade_a", sinyal: "resmi", kelengkapan: "fullset", ts: Date.now() - 3 * 86400000 },
          { kode: "DLH-TT-SEED-02", namaLama: "Redmi Note 10", namaTujuan: "Redmi Note 13", pasaran: 1450000, taksiran: 1180000, selisih: 1120000, grade: "grade_b", sinyal: "resmi", kelengkapan: "unit_charger", ts: Date.now() - 2 * 86400000 },
          { kode: "DLH-TT-SEED-03", namaLama: "Samsung A54", namaTujuan: "Samsung A55", pasaran: 3100000, taksiran: 2650000, selisih: 2350000, grade: "grade_a", sinyal: "inter_beacukai", kelengkapan: "fullset", ts: Date.now() - 2 * 86400000 },
          { kode: "DLH-TT-SEED-04", namaLama: "Oppo Reno 8", namaTujuan: "Oppo Reno 11", pasaran: 2750000, taksiran: 2180000, selisih: 2820000, grade: "grade_c", sinyal: "resmi", kelengkapan: "batangan", ts: Date.now() - 86400000 }
        ];
        seed.forEach(s => DillahLedger.upsert(s));
        state.currentTradeInVoucher = "DLH-TT-SEED-05";
        document.getElementById("calcHpLamaNama").value = "Vivo V29 256GB";
        document.getElementById("calcHpLamaPasar").value = "3600000";
        document.getElementById("calcKondisiFisik").value = "grade_b";
        calculateTradeIn();
        await new Promise(r => setTimeout(r, 900));
        window.setLedgerRange(14);
        // Buka tab Tukar Tambah agar kartu benar-benar terlihat
        const navItem = document.querySelectorAll(".nav-item")[2];
        if (navItem && window.onNavClick) window.onNavClick(navItem, 2);
        document.getElementById("ledgerCard").scrollIntoView({ block: "center" });
        await new Promise(r => setTimeout(r, 700));
        return true;
      })()`);

      const shot = await cdp(ws, "Page.captureScreenshot", { format: "png", captureBeyondViewport: true });
      if (shot && shot.data) {
        const out = path.join(DIR, "selftest_ledger.png");
        fs.writeFileSync(out, Buffer.from(shot.data, "base64"));
        results.screenshot = out;
        results.screenshotBytes = fs.statSync(out).size;
      }
      results.seededCount = await evalJS(ws, "DillahLedger.count()");
    } catch (e) {
      results.screenshot = "err:" + e.message;
    }

  } catch (e) {
    results.fatal = e.message;
  } finally {
    try { if (ws) ws.close(); } catch (e) {}
    chrome.kill("SIGKILL");
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  }

  console.log(JSON.stringify(results, null, 2));
})();
